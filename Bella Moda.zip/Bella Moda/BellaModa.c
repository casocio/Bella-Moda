#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <windows.h>


/* Funzioni richiamate in parti del programma */
#define MAX_LINE_LENGTH 185
#define MAX_STATE_LENGTH 20
#define MAX_CODE_LENGTH 9

typedef struct // Struttura per rappresentare la spedizione
{
    unsigned short int orderNumber;
    char shippingState[MAX_STATE_LENGTH];
} Order;

void SetColor(short);
void clearInputBuffer(void);
void whiteSpaceRemover(char *);
void errorChoice(void);
unsigned short int getOrderNumber(void);
void printfShipping(Order*, time_t*);
void showShipping(void);


/* Registrazione e Accesso */
#define MAX_USERNAME_LENGTH 22
#define MAX_PASSWORD_LENGTH 22
#define MAX_ADDRESS_LENGTH 102
#define MAX_CREDIT_CARD_LENGTH 18

typedef struct // Struttura per rappresentare un utente
{
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    char address[MAX_ADDRESS_LENGTH];
    char creditCard[MAX_CREDIT_CARD_LENGTH];
    double moneyCreditCard;
} User;

void welcomeScreen(void);
void registerUser(void);
int loginUser(void);
void forgotPassword(void);
void optionAccess(void);

char loggedInUsername[MAX_USERNAME_LENGTH]; // Variabile per salvare il nome dell'utente loggato


/* Schermata Amministratore */
#define MAX_NAME_LENGTH 32

typedef struct // Struttura per rappresentare un prodotto
{
    unsigned short int id;
    char name[MAX_NAME_LENGTH];
    unsigned short int amount;
    double price;
} Product;

void administratorScreen(void);
void showProducts(void);
void showCatalogue(const char*, bool);
bool isProductExist(const char*);
void newEntryProduct(const char*, bool);
void changeProduct(const char*, bool);
void removeProduct(const char*, bool);
void productSelection(void (*)(const char*, bool), bool);
void showDiscountCodes(void);
void addDiscountCodes(void);
void removeDiscountCodes(void);
void updateStats(unsigned short int, unsigned short int, double, bool);
void planning(void);
void optionAdministrator(void);


/* Schermata Utente */
void userScreen(void);
double getMoneyCreditCard(const char*);
void userProfile(void);
int saveCartToFile(int);
void addCart(int*, const char*, bool);
void showCart(int*);
void cartSelection(int*, bool);
void editCart(int*);
double getDiscount(const char*);
double getTotalPrice(void);
unsigned short int getTotalQuantity(void);
void saveOrder(unsigned short int, unsigned short int, double);
void updateMoney(const char*, double);
void buyProducts(int*);
void showOrders(void);
void returnsAndRefunds(void);
void optionUser(void);


// Inizializza il numero totale di prodotti che � possibile creare
Product list_product[100];
Product product_cart[100];
int num_products = sizeof(list_product) / sizeof(Product);

int main(void)
{
	setlocale(LC_ALL, ""); // Permette di inserire un range di caratteri pi� ampio, come le lettere accentate
    optionAccess();

    if(strcmp(loggedInUsername, "Nico") == 0 || strcmp(loggedInUsername, "Vale") == 0) // Permette di accedere alle opzioni dell'amministratore
    {
    	optionAdministrator();
    }else
    {
    	optionUser();
    }

    return 0;
}


/* Funzioni richiamate in parti del programma */

// Funzione che cambia il colore del testo
void SetColor(short Color)
{
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hCon, Color);
}

void clearInputBuffer(void)
{
    char c;
	while((c = getchar()) != '\n')
	{
	    // scarta il carattere
	}
}

void whiteSpaceRemover(char *str)
{
	// Rimuove gli spazi bianchi iniziali
    int i = 0;
    while(isspace((unsigned char)str[i]))
    {
        i++;
    }

    if(i > 0)
    {
        int j = 0;
        while(str[i])
        {
            str[j] = str[i];
            i++;
            j++;
        }
        str[j] = '\0';
    }
    
	// Rimuove gli spazi finali dall'input dell'utente
    int len = strlen(str);
    while(len > 0 && isspace((unsigned char)str[len-1]))
    {
        len--;
    }
    str[len] = '\0';
}

// Funzione che stampa un messaggio di errore
void errorChoice(void)
{
	SetColor(4);
	puts("ERRORE: Scelta non valida. Riprova.\n");
	SetColor(15);
	system("pause");
	return;
}

// Funzione che permette di stabilire il numero dell'ordine attuale
unsigned short int getOrderNumber(void)
{
	char filename[45];
    sprintf(filename, "%s_orders.csv", loggedInUsername);
    
    FILE *file = fopen(filename, "r");
    if(file == NULL)
	{
        file = fopen(filename, "w");
    }
    
    unsigned short int orderNumber = 1;
    unsigned short int maxOrderNumber = 0;
    
	char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        unsigned short int currentOrderNumber;
        sscanf(line, "%hu", &currentOrderNumber);
        if(currentOrderNumber > maxOrderNumber)
        {
            maxOrderNumber = currentOrderNumber;
        }
    }
    fclose(file);

    orderNumber = maxOrderNumber + 1;
    return orderNumber;
}

// Funzione che permette di stampare lo stato di spedizione
void printfShipping(Order* newOrder, time_t* start)
{
    time_t now = time(NULL);
    double diff = difftime(now, *start);
    printf("Stato di spedizione dell'ordine %hu: %s\n", newOrder->orderNumber, newOrder->shippingState);
}

// Funzione che monitora la spedizione
void showShipping(void)
{
    Order newOrder;
    newOrder.orderNumber = getOrderNumber();

    printf("L'ordine con numero %hu � stato creato\n\n", newOrder.orderNumber);

    sprintf(newOrder.shippingState, "In transito");
    time_t start = time(NULL); // Memorizza il tempo di inizio

    int i, j;
    time_t start_time, current_time;

    for(i = 0; i <= 100; i+=10)
    {
        printf("[");
        for(j = 0; j < i; j += 5)
        {
            printf("=");
        }
        for(j; j <= 10; j += 5)
        {
            printf(" ");
        }
        printf("] %d%%\r", i);//%d%% serve per mettere la % subito dopo il numero
        fflush(stdout);

        start_time = time(NULL);
        do
        {
            current_time = time(NULL);
        }while(current_time - start_time < 1); // Cambia il numero di secondi a tuo piacimento. 

        if(i == 10)
        {
            sprintf(newOrder.shippingState, "Pacco in transito");
            printfShipping(&newOrder, &start);
        }
        else if (i == 30)
        {
            sprintf(newOrder.shippingState, "Pacco in consegna");
            printfShipping(&newOrder, &start);
        }
        else if(i == 100)
        {
            sprintf(newOrder.shippingState, "Pacco consegnato");
            printfShipping(&newOrder, &start);
        }
    }
    
    SetColor(3);
    puts("\nGrazie per aver effettuato l'acquisto da noi!");
    SetColor(15);
}


/* Registrazione e Accesso */
void welcomeScreen(void)
{
    system("cls");
    SetColor(6);
    printf("%s", "Ti diamo il benvenuto nel negozio di abbigliamento: ");
    SetColor(12);
    puts("Bella Moda!");

    SetColor(4);
    printf("%s", "ATTENZIONE: ");
    SetColor(15);
    printf("Per poter proseguire, bisogna accedere o registrarsi.\n"
    	   "\n1.Registrati\n2.Accedi\n3.Password dimenticata\n0.Esci dal programma\n"
    	   "\nInserisci il numero in base alla tua scelta: ");
}

// Funzione per registrare un nuovo utente
void registerUser(void)
{
    FILE *file = fopen("users.csv", "r");
    if(file == NULL)
    {
        // Se il file non esiste, crea un nuovo file e scrive i dati iniziali
        file = fopen("users.csv", "w");
    }

    system("cls");
    SetColor(2);
    puts("Registrazione\n");
    SetColor(4);
    printf("%s", "ATTENZIONE: ");
    SetColor(15);
    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi!"
    	   "\nTuttavia, � possibile usare gli spazi vuoti solo nell'indirizzo.\n\n");

    User newUser;
    
    printf("%s", "Username (max 20): ");
    fgets(newUser.username, sizeof(newUser.username), stdin);
	newUser.username[strcspn(newUser.username, "\n")] = '\0';
	if(strlen(newUser.username) == 0 || strlen(newUser.username) >= MAX_USERNAME_LENGTH - 1 || sscanf(newUser.username, " %*21[^\n]") != 0)
	{
		if(strlen(newUser.username) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Username non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }else if(strlen(newUser.username) >= MAX_USERNAME_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return;
	    }  
	}
	
	// Controllo degli spazi vuoti e dei punti-virgola nello username
	char *ptrUs = newUser.username;
	while(*ptrUs != '\0')
	{
	    if(*ptrUs == ' ' || *ptrUs == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nello username!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    ptrUs++;
	}
	
	// Verifica se l'utente esiste gi�
    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token = strtok(line, ";");
        if(token != NULL && strcmp(token, newUser.username) == 0)
        {
            SetColor(4);
            printf("\nERRORE: L'utente esiste gi�! Si prega di scegliere un altro username.\n\n");
            SetColor(15);
            system("pause");
            fclose(file);
            return;
        }
    }

    printf("%s", "Password (max 20): ");
    fgets(newUser.password, sizeof(newUser.password), stdin);
	newUser.password[strcspn(newUser.password, "\n")] = '\0';
	if(strlen(newUser.password) == 0 || strlen(newUser.password) >= MAX_PASSWORD_LENGTH - 1 || sscanf(newUser.password, " %*21[^\n]") != 0)
	{
		if(strlen(newUser.password) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Password non valida!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }else if(strlen(newUser.password) >= MAX_PASSWORD_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return;
	    }
	}
	
	// Controllo degli spazi vuoti e dei punti-virgola nella password
	char *ptrPs = newUser.password;
	while(*ptrPs != '\0')
	{
	    if(*ptrPs == ' ' || *ptrPs == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella password!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    ptrPs++;
	}

    printf("%s", "Indirizzo di casa (max 100): ");
    fgets(newUser.address, sizeof(newUser.address), stdin);
	newUser.address[strcspn(newUser.address, "\n")] = '\0';
	whiteSpaceRemover(newUser.address);
    if(strlen(newUser.address) == 0 || strlen(newUser.address) >= MAX_ADDRESS_LENGTH - 1 || sscanf(newUser.address, " %*101[^\n]") != 0)
	{
		if(strlen(newUser.address) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Indirizzo di casa non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }else if(strlen(newUser.address) >= MAX_ADDRESS_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return;
	    }
	}
	
	// Controllo dei punti-virgola nell'indirizzo di casa
	char *ptrAd = newUser.address;
	while(*ptrAd != '\0')
	{
	    if(*ptrAd == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: I punti-virgola non sono consentiti nell'indirizzo di casa!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    ptrAd++;
	}
	
	char choice[3];
	char input[100]; // Imposta una certa dimensione per l'inserimento del denaro
	bool yesCreditCard;
	
	printf("\nPreferenza di pagamento:\n1.Pagamento alla consegna\n"
           "2.Carta di credito\n\nInserisci il numero in base alla tua scelta: ");
	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
    {
        // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
        if(choice[strlen(choice) - 1] == '\n')
        {
            choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
        }else
        {
            clearInputBuffer();
        }
    }

    if(strlen(choice) == 1)
    {
        if(choice[0] == '1')
        {
	        yesCreditCard = false;
		}else if(choice[0] == '2')
		{
			yesCreditCard = true;
        	bool foundCreditCard = false;
        	double money = 0.0;
        	
            printf("\nNumero carta di credito (max 16): ");
			fgets(newUser.creditCard, sizeof(newUser.creditCard), stdin);
			newUser.creditCard[strcspn(newUser.creditCard, "\n")] = '\0';
			if(strlen(newUser.creditCard) == 0 || strlen(newUser.creditCard) >= MAX_CREDIT_CARD_LENGTH - 1 || strlen(newUser.creditCard) < MAX_CREDIT_CARD_LENGTH - 2 || sscanf(newUser.creditCard, " %*17[^\n]") != 0)
			{
				if(strlen(newUser.creditCard) == 0)
				{
					SetColor(4);
				    puts("\nERRORE: Carta di credito non valida!\n");
				    SetColor(15);
				    system("pause");
				    fclose(file);
				    return;
				}else if(strlen(newUser.creditCard) >= MAX_CREDIT_CARD_LENGTH - 1)
				{
				    SetColor(4);
				    puts("\nERRORE: Lunghezza carta di credito non valida!\n");
				    SetColor(15);
				    system("pause");
				    clearInputBuffer();
					fclose(file);
				    return;
				}else if(strlen(newUser.creditCard) < MAX_CREDIT_CARD_LENGTH - 2)
				{
					SetColor(4);
				    puts("\nERRORE: Lunghezza carta di credito non valida!\n");
				    SetColor(15);
				    system("pause");
				    fclose(file);
				    return;
				}
			}
				
			// Controllo degli spazi vuoti e dei punti-virgola nella carta di credito
			char *ptrCc = newUser.creditCard;
			while(*ptrCc != '\0')
			{
				if(*ptrCc == ' ' || *ptrCc == ';')
				{
				    SetColor(4);
				    puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella carta di credito!\n");
				    SetColor(15);
				    system("pause");
				    fclose(file);
				    return;
				}
				ptrCc++;
			}
				
			// Controllo dell'inserimento di soli numeri nella carta di credito
			int i;
			for(i = 0; i < strlen(newUser.creditCard); i++)
			{
			    if(!isdigit(newUser.creditCard[i]))
				{
			        SetColor(4);
			        puts("\nERRORE: La carta di credito deve contenere solo numeri!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        return;
			    }
			}
			
			// Verifica se la carta di credito esiste gi�
			rewind(file);
			while(fgets(line, sizeof(line), file) != NULL)
			{
			    char *token = strtok(line, ";");
			    token = strtok(NULL, ";");
				token = strtok(NULL, ";");
				token = strtok(NULL, ";");
				if(token != NULL && strcmp(token, newUser.creditCard) == 0)
				{
					foundCreditCard = true;
					token = strtok(NULL, " ");
			        double value = atof(token);
			        money = value;
			        newUser.moneyCreditCard = money;
			        break;
				}   
			}
			
			if(!foundCreditCard) // Se la carta di credito non corrisponde a nessuna carta nel file
			{
				printf("%s", "Denaro presente nella carta di credito (max 999999,99): ");
			    fgets(input, sizeof(input), stdin);
			    if(strlen(input) <= 1)
				{
			        SetColor(4);
			        puts("\nERRORE: Nessun dato inserito!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        return;
			    }else if(sscanf(input, "%lf", &newUser.moneyCreditCard) != 1 || strchr(input, ' ') != NULL)
				{
			        SetColor(4);
			        puts("\nERRORE: Denaro carta di credito non valido!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        return;
			    }else if(newUser.moneyCreditCard < 0.0 || newUser.moneyCreditCard > 999999.99)
				{
			        SetColor(4);
			        puts("\nERRORE: Il denaro inserito � insufficiente o troppo elevato!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        return;
			    }
			}
		}else
		{
			fclose(file);
			errorChoice();
		}
		fclose(file);
        
        // Salva il nuovo utente nel file
	    file = fopen("users.csv", "a");
	    if(file == NULL)
	    {
	        SetColor(4);
	        printf("\nERRORE: Impossibile aprire il file!\n\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
	    
		if(choice[0] == '1' || choice[0] == '2')
		{
			if(!yesCreditCard) // Se la preferenza di pagamento � "Pagamento alla consegna"
			{
				fprintf(file, "%s;%s;%s\n", newUser.username, newUser.password, newUser.address);
			}else
			{
				fprintf(file, "%s;%s;%s;%s;%.2lf\n", newUser.username, newUser.password, newUser.address, newUser.creditCard, newUser.moneyCreditCard);
			}
			fclose(file);
			
			SetColor(10);
			puts("\nRegistrazione completata!\n");
			SetColor(15);
			system("pause");
		}
    }else
    {
    	fclose(file);
        errorChoice();
    }
    fclose(file);
}

// Funzione per accedere come utente registrato
int loginUser(void)
{
    FILE *file = fopen("users.csv", "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return 0;
    }
	
	// Controlla se il file contiene utenti registrati
    fseek(file, 0, SEEK_END);
    int file_size = ftell(file);
    
	if(file_size == 0)
    {
        SetColor(4);
        puts("Non ci sono utenti registrati!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
    rewind(file);
	
    system("cls");
    SetColor(2);
    puts("Accesso\n");
    SetColor(15);

    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];

    printf("%s", "Username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';
	if(strlen(username) == 0 || strlen(username) >= MAX_USERNAME_LENGTH - 1 || sscanf(username, " %*21[^\n]") != 0)
	{
		if(strlen(username) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Username non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return 0;
	    }else if(strlen(username) >= MAX_USERNAME_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return 0;
	    }  
	}
	
    // Controllo degli spazi vuoti e dei punti-virgola nello username
    char *ptrUs = username;
	while(*ptrUs != '\0')
	{
	    if(*ptrUs == ' ' || *ptrUs == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nello username!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return 0;
	    }
	    ptrUs++;
	}
    
    printf("%s", "Password: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = '\0';
    if(strlen(password) == 0 || strlen(password) >= MAX_PASSWORD_LENGTH - 1 || sscanf(password, " %*21[^\n]") != 0)
	{
		if(strlen(password) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Password non valida!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return 0;
	    }else if(strlen(password) >= MAX_PASSWORD_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return 0;
	    }
	}
	
	// Controllo degli spazi vuoti e dei punti-virgola nella password
	char *ptrPs = password;
	while(*ptrPs != '\0')
	{
	    if(*ptrPs == ' ' || *ptrPs == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella password!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return 0;
	    }
	    ptrPs++;
	}

    char line[MAX_LINE_LENGTH];
    bool loggedIn = false;
    
	// Controllo corrispondenza dei dati all'interno del file 
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token = strtok(line, ";");
        if(token != NULL && strcmp(token, username) == 0)
        {
            token = strtok(NULL, ";");
            if(token != NULL && strcmp(token, password) == 0)
            {
                loggedIn = true; // Login avvenuto con successo
            	break;
            }
        }
    }
    fclose(file);
    
    if(loggedIn)
	{
		strcpy(loggedInUsername, username); // Copia il nome dell'utente
		SetColor(10);
        puts("\nAccesso effettuato con successo!\n");
        SetColor(15);
		system("pause");
    }else
	{
		SetColor(4);
        puts("\nERRORE: Credenziali errate!\n");
        SetColor(15);
		system("pause");
    }
    return loggedIn;
}

// Funzione per sostituire la password dimenticata 
void forgotPassword(void)
{
    FILE *file = fopen("users.csv", "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return;
    }

    FILE *tempFile = fopen("temp.csv", "w");
    if(tempFile == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile creare il file temporaneo!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
	
	// Controlla se il file contiene utenti registrati
    fseek(file, 0, SEEK_END);
    int file_size = ftell(file);
    
	if(file_size == 0)
    {
        SetColor(4);
        puts("Non ci sono utenti registrati!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        fclose(tempFile);
        remove("temp.csv");
        return;
    }
    rewind(file);
	
    system("cls");
    SetColor(2);
    puts("Cambio Password\n");
    SetColor(4);
    printf("%s", "ATTENZIONE: ");
    SetColor(15);
    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti!\n\n");
	
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    char newPassword[MAX_PASSWORD_LENGTH];

    printf("%s", "Username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';
    if(strlen(username) == 0 || strlen(username) >= MAX_USERNAME_LENGTH - 1 || sscanf(username, " %*21[^\n]") != 0)
	{
		if(strlen(username) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Username non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
			fclose(tempFile);
            remove("temp.csv");
			return;
	    }else if(strlen(username) >= MAX_USERNAME_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
			fclose(tempFile);
            remove("temp.csv");
			return;
	    }  
	}
	
    // Controllo degli spazi vuoti e dei punti-virgola nello username
    char *ptrUs = username;
	while(*ptrUs != '\0')
	{
	    if(*ptrUs == ' ' || *ptrUs == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nello username!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
			fclose(tempFile);
            remove("temp.csv");
			return;
	    }
	    ptrUs++;
	}

    // Cerca la riga dell'utente e aggiorna la password
    char line[MAX_LINE_LENGTH];
    bool foundUser = false;

    while(fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, "\n")] = '\0';

        char currentUser[MAX_USERNAME_LENGTH];
        char currentPassword[MAX_PASSWORD_LENGTH];
        char currentAddress[MAX_ADDRESS_LENGTH];
        char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
        double currentMoney;

        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
        if(strcmp(currentUser, username) == 0)
        {
            foundUser = true;
			
            printf("%s", "Nuova password (max 20): ");
            fgets(newPassword, sizeof(newPassword), stdin);
            newPassword[strcspn(newPassword, "\n")] = '\0';
            if(strlen(newPassword) == 0 || strlen(newPassword) >= MAX_PASSWORD_LENGTH - 1 || sscanf(newPassword, " %*21[^\n]") != 0)
            {
                if(strlen(newPassword) == 0)
                {
                    SetColor(4);
                    puts("\nERRORE: Password non valida!\n");
                    SetColor(15);
                    system("pause");
                    fclose(file);
                	fclose(tempFile);
                	remove("temp.csv");
                	return;
                }else if(strlen(newPassword) >= MAX_PASSWORD_LENGTH - 1)
                {
                    SetColor(4);
                    puts("\nERRORE: Hai inserito troppi caratteri!\n");
                    SetColor(15);
                    system("pause");
                    clearInputBuffer();
                    fclose(file);
                    fclose(tempFile);
                	remove("temp.csv");
                	return;
                }
            }
            
            // Controllo degli spazi vuoti e dei punti-virgola nella nuova password
			char *ptrNps = newPassword;
			while(*ptrNps != '\0')
			{
			    if(*ptrNps == ' ' || *ptrNps == ';')
				{
			        SetColor(4);
			        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella nuova password!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
                	remove("temp.csv");
			        return;
			    }
			    ptrNps++;
			}
            
            if(strcmp(currentPassword, newPassword) == 0)
		    {
		        SetColor(4);
		        puts("\nERRORE: La nuova password non pu� essere uguale a quella attuale!\n");
		        SetColor(15);
		        system("pause");
		        fclose(file);
		        fclose(tempFile);
		        remove("temp.csv");
		        return;
		    }
		    
		    if(strlen(currentCreditCard) == 0) // Se l'utente non ha una carta di credito
		    {
            	fprintf(tempFile, "%s;%s;%s\n", currentUser, newPassword, currentAddress);
	        }else
	        {
	            fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, newPassword, currentAddress, currentCreditCard, currentMoney);
	        }
        }else
        {
            fprintf(tempFile, "%s\n", line);
        }
    }
    fclose(file);
    fclose(tempFile);

    remove("users.csv");
    rename("temp.csv", "users.csv");

    // Gestisce gli errori
    if(!foundUser)
    {
    	SetColor(4);
        puts("\nERRORE: Utente non trovato!\n");
        SetColor(15);
        system("pause");
        fclose(file);
		fclose(tempFile);
		remove("temp.csv");
        return;
    }else
	{
		SetColor(10);
	    puts("\nPassword modificata correttamente!\n");
	    SetColor(15);
	    system("pause");
	    fclose(file);
	}
}

// Men� iniziale di accesso
void optionAccess(void)
{
	char choice[3];
	int loggedIn = 0;
	
	do
	{
		welcomeScreen();
        if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2) 
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }
        
		if(strlen(choice) == 1)
		{	
			switch(choice[0])
			{
	        	case '0':
	        		SetColor(3);
	        		puts("Grazie per aver visitato il nostro negozio online!");
					SetColor(15);
					exit(1);
	        		break;
	            
				case '1':
	                registerUser();
	                break;
	            
				case '2':
	                loggedIn = loginUser();
	                break;
	            
				case '3':
	                forgotPassword();
	                break;
	            
				default:
					errorChoice();
	        }
    	}else
		{
			errorChoice();
		}
		
		if(loggedIn) // Se il login � avvenuto con successo, allora esce dal ciclo
		{
			break;
		}
    }while(1);
}


/* Schermata Amministratore*/
void administratorScreen(void)
{
    system("cls");
    SetColor(6);
    printf("%s", "Benvenuto Amministratore ");
    SetColor(12);
    printf("%s!\n\n", loggedInUsername);
    SetColor(15);
	printf("1.Inserisci nuovo prodotto\n2.Visualizza prodotti\n3.Cambia prodotto\n"
           "4.Rimuovi prodotto\n5.Inserisci codice sconto\n6.Rimuovi codice sconto\n"
		   "7.Analisi e Pianificazione\n0.Esci dal programma\n\n"
		   "Inserisci il numero in base alla tua scelta: ");
}

void showProducts(void)
{
	system("cls");
	SetColor(2);
	puts("Catalogo prodotti\n");
    SetColor(15);
	printf("1.Camicie/Maglie\n2.Jeans/Pantaloni\n3.Cappotti\n"
	"4.Scarpe\n5.Indumenti invernali\n0.Torna indietro\n"
	"\nInserisci il numero in base alla tua scelta: ");
}

// Funzione che mostra il catalogo prodotto delle 5 categorie
void showCatalogue(const char *category, bool showZeroQuantity)
{
    char filename[20];
    sprintf(filename, "%s_products.csv", category);
    
    FILE *file = fopen(filename, "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        return;
    }
	
	if(strcmp(category, "Shirts") == 0)
	{
		system("cls");
		SetColor(2);
		puts("Catalogo Camicie/Maglie\n");
		SetColor(15);
	}else if(strcmp(category, "Jeans") == 0)
	{
		system("cls");
		SetColor(2);
		puts("Catalogo Jeans/Pantaloni\n");
		SetColor(15);
	}else if(strcmp(category, "Coat") == 0)
	{
		system("cls");
		SetColor(2);
		puts("Catalogo Cappotti\n");
		SetColor(15);
	}else if(strcmp(category, "Shoes") == 0)
	{
		system("cls");
		SetColor(2);
		puts("Catalogo Scarpe\n");
		SetColor(15);
	}else if(strcmp(category, "Winter") == 0)
	{
		system("cls");
		SetColor(2);
		puts("Catalogo Indumenti invernali\n");
		SetColor(15);
	}
	
	SetColor(11);
	printf("+----------------+--------------------------------+------------------+------------+\n"
		   "|       ID       |              Nome              |     Quantit�     |   Prezzo   |\n"
		   "+----------------+--------------------------------+------------------+------------+\n");
	
	// Lettura e stampa dei dati dal file
    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token;
        token = strtok(line, ";");
        unsigned short int id = atoi(token);

        token = strtok(NULL, ";");
        char name[MAX_NAME_LENGTH];
        strcpy(name, token);

        token = strtok(NULL, ";");
        unsigned short int amount = atoi(token);

        token = strtok(NULL, " ");
        double price = atof(token);
		
        if(showZeroQuantity || amount > 0) // Mostra, o no, i prodotti con quantit� zero
        {
            printf("+----------------+--------------------------------+------------------+------------+\n");
            printf("| %-14hu | %-30s | %-16hu | %.2lf\t  |\n", id, name, amount, price);
            printf("+----------------+--------------------------------+------------------+------------+\n");
        }
    }
	fclose(file);
	
	SetColor(15);
    printf("\n");
}

// Funzione che controlla l'esistenza di un prodotto all'interno di una delle 5 categorie
bool isProductExist(const char *productName)
{
	char categories[5][20] = {"Shirts", "Jeans", "Coat", "Shoes", "Winter"};
	
	int i;
    for(i = 0; i < 5; i++)
    {
        char filename[20];
        sprintf(filename, "%s_products.csv", categories[i]);

        FILE *file = fopen(filename, "r");
        if(file != NULL)
		{
			char line[MAX_LINE_LENGTH];
	        while(fgets(line, sizeof(line), file) != NULL)
	        {
	            char name[MAX_NAME_LENGTH];
	            sscanf(line, "%*hu;%30[^;]", name);
	            if(strcasecmp(name, productName) == 0)
	            {
	                SetColor(4);
			        printf("\nERRORE: Il prodotto '%s' esiste gi�!\n\n", productName);
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        return true;
	            }
	        }
	        fclose(file);	
		}
    }
    return false;
}

// Funzione per inserire un nuovo prodotto
void newEntryProduct(const char *category, bool showZeroQuantity)
{
	char filename[20];
    sprintf(filename, "%s_products.csv", category);
    
    FILE *file = fopen(filename, "r");
    if(file == NULL)
    {
        // Se il file non esiste, crea un nuovo file e scrive i dati iniziali
        file = fopen(filename, "w");
    }
	
    showCatalogue(category, showZeroQuantity);
    
    SetColor(2);
    puts("Inserimento nuovo prodotto\n");
    SetColor(4);
    printf("%s", "ATTENZIONE: ");
    SetColor(15);
    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi!"
    	   "\nTuttavia, � possibile usare gli spazi vuoti solo nel nome del prodotto.\n\n");

    Product newProduct;
    char input[100]; // Imposta una certa dimensione per l'inserimento della quantit� e del prezzo
	
	// Verifica se il file ha raggiunto le 100 linee (prodotti)
    char line[MAX_LINE_LENGTH];
	unsigned short int lineCount = 0;
    
    while(fgets(line, sizeof(line), file) != NULL)
    {
        lineCount++;
    }

    if(lineCount >= 100)
    {
        SetColor(4);
        puts("ERRORE: Il numero massimo di prodotti � stato raggiunto!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
	
    // Leggi l'ultimo ID del prodotto dal file
    unsigned short int last_id = 0;
    
    rewind(file);
	while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token;
        token = strtok(line, ";");
        unsigned short int id = atoi(token);
        if(id > last_id)
        {
            last_id = id;
        }
    }
    fclose(file);

    newProduct.id = last_id + 1;

    printf("%s", "Nome prodotto (max 30): ");
    fgets(newProduct.name, sizeof(newProduct.name), stdin);
    newProduct.name[strcspn(newProduct.name, "\n")] = 0;
    whiteSpaceRemover(newProduct.name);
    newProduct.name[0] = toupper(newProduct.name[0]); // Cambia il primo carattere da minuscolo a maiuscolo
	if(strlen(newProduct.name) == 0 || strlen(newProduct.name) >= MAX_NAME_LENGTH - 1 || sscanf(newProduct.name, " %*31[^\n]") != 0)
	{
		if(strlen(newProduct.name) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Nome del prodotto non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }else if(strlen(newProduct.name) >= MAX_NAME_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return;
	    }  
	}
	
	// Controllo dei punti-virgola nel nome del prodotto
	char *ptrNpn = newProduct.name;
	while(*ptrNpn != '\0')
	{
	    if(*ptrNpn == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: I punti-virgola non sono consentiti nel nome del prodotto!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    ptrNpn++;
	}
	
	// Verifica se il nome del prodotto esiste gi� nel file
    if(isProductExist(newProduct.name))
	{
		fclose(file);
        return;
	}
	
    printf("%s", "Quantit� prodotto (max 100): ");
    fgets(input, sizeof(input), stdin);
    if(strlen(input) <= 1)
	{
        SetColor(4);
        puts("\nERRORE: Nessun dato inserito per la quantit� del prodotto!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(sscanf(input, "%hu", &newProduct.amount) != 1 || strchr(input, ' ') != NULL)
	{
        SetColor(4);
        puts("\nERRORE: Quantit� prodotto non valida!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(newProduct.amount == 0 || newProduct.amount > 100)
	{
        SetColor(4);
        puts("\nERRORE: Quantit� prodotto nulla o troppo elevata!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }

    printf("%s", "Prezzo prodotto (max 999999,99): ");
    fgets(input, sizeof(input), stdin);
    if(strlen(input) <= 1)
	{
        SetColor(4);
        puts("\nERRORE: Nessun dato inserito per il prezzo del prodotto!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(sscanf(input, "%lf", &newProduct.price) != 1 || strchr(input, ' ') != NULL)
	{
        SetColor(4);
        puts("\nERRORE: Prezzo prodotto non valido!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(newProduct.price == 0.0 || newProduct.price > 999999.99)
	{
        SetColor(4);
        puts("\nERRORE: Non siamo alla Caritas e nemmeno Jeff Bezos!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
    fclose(file);
    
    // Salva il nuovo prodotto nel file
    file = fopen(filename, "a");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return;
    }
    
    fprintf(file, "%hu;%s;%hu;%.2lf\n", newProduct.id, newProduct.name, newProduct.amount, newProduct.price);
    fclose(file);
	
	showCatalogue(category, showZeroQuantity);
    SetColor(2);
    puts("Nuovo prodotto aggiunto correttamente!\n");
    SetColor(15);
    system("pause");
}

// Funzione che cambia le informazioni di un prodotto
void changeProduct(const char *category, bool showZeroQuantity)
{
	char choice[3];
	int cart_index = 0;
    
	do
	{	
		char filename[20];
    	sprintf(filename, "%s_products.csv", category);
		
	    FILE *file = fopen(filename, "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
		
		FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    
	    showCatalogue(category, showZeroQuantity); // Mostra il catalogo prodotti di una delle 5 categorie
	    
	    // Controlla se il file contiene prodotti
        fseek(file, 0, SEEK_END);
        int file_size = ftell(file);
        
		if(file_size == 0)
        {
            SetColor(4);
            puts("Non ci sono prodotti da modificare!\n");
            SetColor(15);
            system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
        }
	    rewind(file);
	    
	    SetColor(2);
	    puts("Modifica prodotto\n");
	    SetColor(4);
	    printf("%s", "ATTENZIONE: ");
	    SetColor(15);
	    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi!"
	    	   "\nTuttavia, � possibile usare gli spazi vuoti solo nel nome del prodotto.\n\n");
	    
	    char newName[MAX_NAME_LENGTH];
	    char defaultName[MAX_NAME_LENGTH];
	    unsigned short int newAmount;
	    double newPrice;
		
		char input[100]; // Imposta una certa dimensione per l'inserimento dell'ID, della quantit� e del prezzo
	    unsigned short int id_to_change;
	    
		printf("%s", "Inserisci l'ID del prodotto da modificare: ");
		fgets(input, sizeof(input), stdin);
	    if(strlen(input) <= 1)
		{
	        SetColor(4);
	        puts("\nERRORE: Nessun ID inserito!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }else if(sscanf(input, "%hu", &id_to_change) != 1 || strchr(input, ' ') != NULL)
		{
	        SetColor(4);
	        puts("\nERRORE: ID prodotto non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }
		
	    char line[MAX_LINE_LENGTH];
	    bool foundProduct = false;
	    
	    while(fgets(line, sizeof(line), file) != NULL)
	    {
	    	line[strcspn(line, "\n")] = '\0';
	        
			unsigned short int currentId;
	        char currentName[MAX_NAME_LENGTH];
	        unsigned short int currentAmount;
	        double currentPrice;
	        
	        sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
	        if(currentId == id_to_change)
	        {
				foundProduct = true;
				
				strncpy(defaultName, currentName, MAX_NAME_LENGTH - 1);
	            defaultName[MAX_NAME_LENGTH - 1] = '\0';
	            
	            printf("%s", "Nome prodotto (max 30): ");
	            fgets(newName, sizeof(newName), stdin);
	            newName[strcspn(newName, "\n")] = 0;
	            whiteSpaceRemover(newName);
	            newName[0] = toupper(newName[0]); // Cambia il primo carattere da minuscolo a maiuscolo
	            if(strlen(newName) == 0 || strlen(newName) >= MAX_NAME_LENGTH - 1 || sscanf(newName, " %*31[^\n]") != 0)
				{
					if(strlen(newName) == 0)
					{
						SetColor(4);
				        puts("\nERRORE: Nome del prodotto non valido!\n");
				        SetColor(15);
				        system("pause");
				        fclose(file);
				        fclose(tempFile);
	            		remove("temp.csv");
						return;
				    }else if(strlen(newName) >= MAX_NAME_LENGTH - 1)
				    {
				        SetColor(4);
				    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
				        SetColor(15);
				        system("pause");
				        clearInputBuffer();
				        fclose(file);
				        fclose(tempFile);
	            		remove("temp.csv");
						return;
				    }  
				}
				
				// Controllo dei punti-virgola nel nuovo nome del prodotto
				char *ptrNn = newName;
				while(*ptrNn != '\0')
				{
				    if(*ptrNn == ';')
					{
				        SetColor(4);
				        puts("\nERRORE: I punti-virgola non sono consentiti nel nome del prodotto!\n");
				        SetColor(15);
				        system("pause");
				        fclose(file);
				        fclose(tempFile);
	            		remove("temp.csv");
						return;
				    }
				    ptrNn++;
				}
				
			    // Verifica se il nuovo nome del prodotto � cambiato
				if(strcmp(defaultName, newName) != 0)
				{
					if(isProductExist(newName)) // Verifica se il nuovo nome del prodotto corrisponde ad un altro prodotto
					{
						fclose(file);
						fclose(tempFile);
						remove("temp.csv");
				        return;
					}
				}
				
				printf("%s", "Quantit� prodotto (max 100): ");
			    fgets(input, sizeof(input), stdin);
				if(strlen(input) <= 1)
				{
			        SetColor(4);
			        puts("\nERRORE: Nessun dato inserito nella quantit� del prodotto!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }else if(sscanf(input, "%hu", &newAmount) != 1 || strchr(input, ' ') != NULL)
				{
			        SetColor(4);
			        puts("\nERRORE: Quantit� prodotto non valida!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }else if(newAmount == 0 || newAmount > 100)
				{
			        SetColor(4);
			        puts("\nERRORE: Quantit� prodotto nulla o troppo elevata!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }
			
			    printf("%s", "Prezzo prodotto (max 999999,99): ");
			    fgets(input, sizeof(input), stdin);
				if(strlen(input) <= 1)
				{
			        SetColor(4);
			        puts("\nERRORE: Nessun dato inserito per il prezzo del prodotto!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }else if(sscanf(input, "%lf", &newPrice) != 1 || strchr(input, ' ') != NULL)
				{
			        SetColor(4);
			        puts("\nERRORE: Prezzo prodotto non valido!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }else if(newPrice == 0.0 || newPrice > 999999.99)
				{
			        SetColor(4);
			        puts("\nERRORE: Non siamo alla Caritas e nemmeno Jeff Bezos!\n");
			        SetColor(15);
			        system("pause");
			        fclose(file);
			        fclose(tempFile);
	            	remove("temp.csv");
					return;
			    }
	            fprintf(tempFile, "%hu;%s;%hu;%.2lf\n", currentId, newName, newAmount, newPrice);
	        }else
	        {
	            fprintf(tempFile, "%s\n", line);
	        }
	    }
	    fclose(file);
	    fclose(tempFile);
	
	    remove(filename);
	    rename("temp.csv", filename);
		
		// Gestisci gli errori
	    if(!foundProduct)
	    {
	        SetColor(4);
	        puts("\nERRORE: Prodotto non trovato!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
			fclose(tempFile);
	        remove("temp.csv");
	        return;
	    }else
		{
			showCatalogue(category, showZeroQuantity); // Mostra il catalogo prodotti di una delle 5 categorie
			SetColor(10);
		    puts("Prodotto modificato con successo!\n");
		    SetColor(15);
		}
		
		printf("Vuoi continuare a modificare i prodotti? (Y/N): ");
    	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if (choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
	}while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione per rimuovere i prodotti
void removeProduct(const char *category, bool showZeroQuantity)
{
	char choice[3];
    
	do
	{
		char filename[20];
    	sprintf(filename, "%s_products.csv", category);
		
	    FILE *file = fopen(filename, "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
	    
	    FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
		
	    showCatalogue(category, showZeroQuantity); // Mostra il catalogo prodotti di una delle 5 categorie
		
		// Controlla se il file contiene prodotti
        fseek(file, 0, SEEK_END);
        int file_size = ftell(file);
        
		if (file_size == 0)
        {
            SetColor(4);
            puts("Non ci sono prodotti da rimuovere!\n");
            SetColor(15);
            system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
        }
	    rewind(file);
		
	    SetColor(2);
	    puts("Rimozione prodotto\n");
	    SetColor(15);
		
		char input[100]; // Imposta una certa dimensione per l'inserimento dell'ID
	    unsigned short int id_to_remove;
	    
		printf("%s", "Inserisci l'ID del prodotto da rimuovere: ");
	    fgets(input, sizeof(input), stdin);
	    if(strlen(input) <= 1)
		{
	        SetColor(4);
	        puts("\nERRORE: Nessun ID inserito!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }else if(sscanf(input, "%hu", &id_to_remove) != 1 || strchr(input, ' ') != NULL)
		{
	        SetColor(4);
	        puts("\nERRORE: ID prodotto non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }
    	
    	// Legge le righe del file
	    char line[MAX_LINE_LENGTH];
		bool foundProduct = false;
		
	    while(fgets(line, sizeof(line), file) != NULL)
	    {
	    	line[strcspn(line, "\n")] = '\0';
	    	
	        unsigned short int currentId;
	        char currentName[MAX_NAME_LENGTH];
	        unsigned short int currentAmount;
	        double currentPrice;
	        
	        sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
	        if(currentId == id_to_remove)
	        {
	        	foundProduct = true;
	        }else
	        {
	        	fprintf(tempFile, "%s\n", line);
	        }
	    }
	    fclose(file);
	    fclose(tempFile);
	
	    remove(filename);
	    rename("temp.csv", filename);
		
		// Gestisce gli errori
	    if(!foundProduct)
	    {
	        SetColor(4);
	        puts("\nERRORE: Prodotto non trovato!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
			fclose(tempFile);
	        remove("temp.csv");
	        return;
	    }else
		{
			// Modifica gli ID dei prodotti successivi
	        FILE *updatedFile = fopen(filename, "r");
	        FILE *tempUpdatedFile = fopen("temp.csv", "w");
	
	        unsigned short int updatedId = 1;
	        while(fgets(line, sizeof(line), updatedFile) != NULL)
	        {
	            line[strcspn(line, "\n")] = '\0';
	
	            unsigned short int currentId;
	            char currentName[MAX_NAME_LENGTH];
	            unsigned short int currentAmount;
	            double currentPrice;
	
	            sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
	            fprintf(tempUpdatedFile, "%hu;%s;%hu;%.2lf\n", updatedId, currentName, currentAmount, currentPrice);
	            updatedId++; // Aumenta l'ID
	        }
	        fclose(updatedFile);
	        fclose(tempUpdatedFile);
	
	        remove(filename);
	        rename("temp.csv", filename);
	        
			showCatalogue(category, showZeroQuantity); // Mostra il catalogo prodotti di una delle 5 categorie
			SetColor(10);
		    puts("Prodotto rimosso correttamente!\n");
		    SetColor(15);
		}
		
		printf("Vuoi continuare a rimuovere i prodotti? (Y/N): ");
    	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if (choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
    }while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione per poter utilizzare "newEntryProduct", "changeProduct", "removeProduct" e "showCatalogue" con le 5 categorie dei prodotti
void productSelection(void (*actionFunc)(const char*, bool), bool showZeroQuantity)
{
    char choice[3];
    
    do
	{
		showProducts();
	    if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
	    {
	        // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
	    }
	
	    if(strlen(choice) == 1)
	    {
	        switch(choice[0])
	        {
		        case '0':
		            break;
		
		        case '1':
		            actionFunc("Shirts", showZeroQuantity);
		            
					if(actionFunc == showCatalogue)
					{
						system("pause");
					}
		            break;
		
		        case '2':
		            actionFunc("Jeans", showZeroQuantity);
		            
		            if(actionFunc == showCatalogue)
					{
						system("pause");
					}
					break;
		
		        case '3':
		            actionFunc("Coat", showZeroQuantity);
		            
		            if(actionFunc == showCatalogue)
					{
						system("pause");
					}
					break;
		
		        case '4':
		            actionFunc("Shoes", showZeroQuantity);
		            
					if(actionFunc == showCatalogue)
					{
						system("pause");
					}
					break;
		
		        case '5':
		            actionFunc("Winter", showZeroQuantity);
		            
					if(actionFunc == showCatalogue)
					{
						system("pause");
					}
					break;
		
		        default:
		            errorChoice();
	        }
	    }
	    else
	    {
	        errorChoice();
	    }
	}while(choice[0] != '0');
}

// Funzione che mostra i codici sconto inseriti
void showDiscountCodes(void)
{
    FILE *file = fopen("coupon.csv", "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return;
    }
	
	SetColor(2);
	puts("Lista Coupon\n");
	SetColor(11);
	printf("+--------------------+---------------------+\n"
		   "|       Codice       |     Percentuale     |\n"
		   "+--------------------+---------------------+\n");
	
	// Lettura e stampa dei dati dal file
    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token = strtok(line, ";");
	    if(token != NULL)
	    {
	        char code[MAX_CODE_LENGTH];
	        strcpy(code, token);
	
	        token = strtok(NULL, " ");
	        unsigned short int discount = atoi(token);
	
	        printf("+--------------------+---------------------+\n");
	        printf("| %-18s | %-19hu |\n", code, discount);
	        printf("+--------------------+---------------------+\n");
	    }
    }
    fclose(file);
	
	SetColor(15);
    printf("\n");
}

// Funzione per inserire nuovi codici sconto
void addDiscountCodes(void)
{
	FILE *file = fopen("coupon.csv", "r");
    if(file == NULL)
    {
        // Se il file non esiste, crea un nuovo file e scrive i dati iniziali
        file = fopen("coupon.csv", "w");
    }
    
	system("cls");
	showDiscountCodes(); // Mostra la lista dei coupon
    SetColor(2);
    puts("Inserimento nuovo coupon\n");
    SetColor(4);
    printf("%s", "ATTENZIONE: ");
    SetColor(15);
    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi!\n\n");

    char code[MAX_CODE_LENGTH];
    unsigned short int discount;
    char input[100]; // Imposta una certa dimensione per l'inserimento della percentuale
  
    printf("Inserisci il codice del coupon (max 7): ");
    fgets(code, sizeof(code), stdin);
    code[strcspn(code, "\n")] = '\0'; // Rimuove il carattere di nuova riga da fgets
    if(strlen(code) == 0 || strlen(code) >= MAX_CODE_LENGTH - 1 || sscanf(code, " %*8[^\n]") != 0)
	{
		if(strlen(code) == 0)
		{
			SetColor(4);
	        puts("\nERRORE: Codice non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }else if(strlen(code) >= MAX_CODE_LENGTH - 1)
	    {
	        SetColor(4);
	    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
	        SetColor(15);
	        system("pause");
	        clearInputBuffer();
	        fclose(file);
	        return;
	    }
	}
	
	// Controllo degli spazi vuoti e dei punti-virgola nel codice
	char *ptrCd = code;
	while(*ptrCd != '\0')
	{
	    if(*ptrCd == ' ' || *ptrCd == ';')
		{
	        SetColor(4);
	        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nel codice!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    ptrCd++;
	}
	
	// Verifica se il codice esiste gi�
    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token = strtok(line, ";");
        if(token != NULL && strcmp(token, code) == 0)
        {
            SetColor(4);
            printf("\nERRORE: Il codice esiste gi�!\n\n");
            SetColor(15);
            system("pause");
            fclose(file);
            return;
        }
    }
    
    printf("Inserisci la percentuale di sconto (1-100): ");
    fgets(input, sizeof(input), stdin);
    if(strlen(input) <= 1)
	{
        SetColor(4);
        puts("\nERRORE: Nessun dato inserito!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(sscanf(input, "%hu", &discount) != 1 || strchr(input, ' ') != NULL)
	{
        SetColor(4);
        puts("\nERRORE: Percentuale non valida!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }else if(discount < 0 || discount > 100)
	{
        SetColor(4);
        puts("\nERRORE: La percentuale inserita � insufficiente o troppo elevata!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
    fclose(file);
    
    // Salva il codice e la percentuale di sconto nel file CSV
    file = fopen("coupon.csv", "a");
    if(file == NULL)
	{
        SetColor(4);
        printf("\nERRORE: Impossibile aprire il file!\n\n");
        SetColor(15);
        system("pause");
        return;
    }
    fprintf(file, "%s;%hu\n", code, discount);
    fclose(file);
    
    system("cls");
    showDiscountCodes(); // Mostra la lista dei coupon
    SetColor(10);
	puts("Coupon aggiunto con successo!\n");
	SetColor(15);
	system("pause");
}

// Funzione per rimuovere i prodotti
void removeDiscountCodes(void)
{
	char choice[3];
    
	do
	{
	    FILE *file = fopen("coupon.csv", "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
	    
	    FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
		
		system("cls");
	    showDiscountCodes(); // Mostra la lista dei coupon
		
		// Controlla se il file contiene coupon
        fseek(file, 0, SEEK_END);
        int file_size = ftell(file);
        
		if (file_size == 0)
        {
            SetColor(4);
            puts("Non ci sono coupon da rimuovere!\n");
            SetColor(15);
            system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
        }
	    rewind(file);
		
	    SetColor(2);
	    puts("Rimozione coupon\n");
	    SetColor(15);
	    
	    char coupon_to_remove[MAX_CODE_LENGTH];
	    
		printf("Inserisci il codice del coupon da rimuovere: ");
	    fgets(coupon_to_remove, sizeof(coupon_to_remove), stdin);
	    coupon_to_remove[strcspn(coupon_to_remove, "\n")] = '\0'; // Rimuove il carattere di nuova riga da fgets
	    if(strlen(coupon_to_remove) == 0 || strlen(coupon_to_remove) >= MAX_CODE_LENGTH - 1 || sscanf(coupon_to_remove, " %*8[^\n]") != 0)
		{
			if(strlen(coupon_to_remove) == 0)
			{
				SetColor(4);
		        puts("\nERRORE: Codice non valido!\n");
		        SetColor(15);
		        system("pause");
		        fclose(file);
		        fclose(tempFile);
            	remove("temp.csv");
		        return;
		    }else if(strlen(coupon_to_remove) >= MAX_CODE_LENGTH - 1)
		    {
		        SetColor(4);
		    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
		        SetColor(15);
		        system("pause");
		        clearInputBuffer();
		        fclose(file);
		        fclose(tempFile);
            	remove("temp.csv");
		        return;
		    }
		}
    
	    char line[MAX_LINE_LENGTH];
		bool foundCoupon = false;
		
	    while(fgets(line, sizeof(line), file) != NULL)
	    {
	    	line[strcspn(line, "\n")] = '\0';
	    	
	        char currentCode[MAX_CODE_LENGTH];
    		unsigned short int currentDiscount;
	        
	        sscanf(line, "%[^;];%hu", currentCode, &currentDiscount);
	        if(strcmp(currentCode, coupon_to_remove) == 0)
	        {
	        	foundCoupon = true;
	        }else
	        {
	        	fprintf(tempFile, "%s\n", line);
	        }
	    }
	    fclose(file);
	    fclose(tempFile);
	
	    remove("coupon.csv");
	    rename("temp.csv", "coupon.csv");
		
	    if(!foundCoupon)
	    {
	        SetColor(4);
	        puts("\nERRORE: Coupon non trovato!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
            remove("temp.csv");
	        return;
	    }else
		{
			system("cls");
	        showDiscountCodes(); // Mostra la lista dei coupon
			SetColor(10);
		    puts("Coupon rimosso correttamente!\n");
		    SetColor(15);
		}
		
		printf("Vuoi continuare a rimuovere prodotti? (Y/N): ");
    	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
    }while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione che aggiorna le statistiche
void updateStats(unsigned short int productsSold, unsigned short int orders, double revenue, bool decrement)
{
	FILE *file = fopen("stats.csv", "r");
    if(file == NULL)
	{
        // Se il file non esiste, crea un nuovo file e scrivi i dati iniziali
        file = fopen("stats.csv", "w");
        if(file != NULL)
		{
            fprintf(file, "%u;%u;%.2lf\n", productsSold, orders, revenue);
        }
    }else
	{
        // Se il file esiste, leggi i dati esistenti e aggiorna i valori
        unsigned short int currentProductsSold;
		unsigned short int currentOrders;
        double currentRevenue;
        
        fscanf(file, "%hu;%hu;%lf\n", &currentProductsSold, &currentOrders, &currentRevenue);
        fclose(file);
        
        if(decrement)
        {
            currentProductsSold -= productsSold;
            currentOrders -= orders;
            currentRevenue -= revenue;
        }else
        {
            currentProductsSold += productsSold;
            currentOrders += orders;
            currentRevenue += revenue;
        }

        file = fopen("stats.csv", "w");
        if(file != NULL)
		{
            fprintf(file, "%hu;%hu;%.2lf", currentProductsSold, currentOrders, currentRevenue);
        }
    }
	fclose(file);
}

// Funzione per controllare ricavi e totale prodotti, ordini e utenti
void planning(void)
{
	system("cls");
    SetColor(2);
    puts("Analisi e Pianificazione\n");
    SetColor(15);
	
    unsigned int totalUsers = 0;
    unsigned short int totalProductsSold = 0;
    unsigned short int totalOrders = 0;
    double totalRevenue = 0.0;
	
	FILE *usersFile = fopen("users.csv", "r");
	if(usersFile != NULL)
	{
	    char line[MAX_LINE_LENGTH];
	    while(fgets(line, sizeof(line), usersFile) != NULL)
		{
	        totalUsers++;
	    }
	    fclose(usersFile);
	}else
	{
		SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return;	
	}
	
	FILE *statsFile = fopen("stats.csv", "r");
    if(statsFile != NULL)
    {
        unsigned short int productsSold;
        unsigned short int orders;
        double revenue;

        fscanf(statsFile, "%hu;%hu;%lf", &productsSold, &orders, &revenue);
        fclose(statsFile);

        totalProductsSold = productsSold;
        totalOrders = orders;
        totalRevenue = revenue;
    }else
	{
		SetColor(4);
	    puts("ERRORE: Impossibile aprire il file!\n");
	    SetColor(15);
	    system("pause");
	    fclose(usersFile);
		return;
	}
	
	printf("Numero totale di utenti registrati: %u\n", totalUsers);
	printf("Numero totale di prodotti venduti: %hu\n", totalProductsSold);
    printf("Numero totale di ordini effettuati: %hu\n", totalOrders);
    printf("Ricavo totale: %.2lf\n\n", totalRevenue);
    
    system("pause");
}

// Men� per schermata amministratore
void optionAdministrator(void)
{
	// Inizializza l'array list_product con valori di default
	int i;
    for(i = 0; i < num_products; i++)
    {
        list_product[i].id = 0;
        strcpy(list_product[i].name, "");
        list_product[i].amount = 0;
        list_product[i].price = 0.0;
    }
    
    char choice[3];
    
	do
	{
		administratorScreen();
        if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2) 
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }
        
		if(strlen(choice) == 1)
		{	
			switch(choice[0])
			{
	        	case '0':
	        		SetColor(3);
	        		puts("Arrivederci Master!");
					SetColor(15);
					exit(1);
	        		break;
	            
				case '1':
	                productSelection(newEntryProduct, true);
	                break;
	            
				case '2':
	                productSelection(showCatalogue, true);
	                break;
	            
				case '3':
	                productSelection(changeProduct, true);
	                break;
	            
	            case '4':
	                productSelection(removeProduct, true);
	                break;
	            
	            case '5':
	                addDiscountCodes();
	                break;
	            
	            case '6':
	            	removeDiscountCodes();
	                break;
	            
	            case '7':
	            	planning();
	            	break;
	            
				default:
					errorChoice();
	        }
    	}else
		{
			errorChoice();
		}
    }while(1);
}


/* Schermata Utente */
void userScreen(void)
{
	system("cls");
	SetColor(6);
    printf("%s", "Benvenuto/a ");
    SetColor(12);
    printf("%s!\n\n", loggedInUsername);
	SetColor(15);
	printf("1.Profilo\n2.Visualizza catalogo\n3.Aggiungi prodotto al carrello\n"
	"4.Carrello\n5.Modifica carrello\n6.Effettua acquisto\n7.Gestisci resi/rimborsi\n"
	"0.Esci dal programma\n\nInserisci il numero in base alla tua scelta: ");
}

// Funzione che restituisce il denaro della carta di credito
double getMoneyCreditCard(const char *creditCard)
{
    FILE *file = fopen("users.csv", "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return 0.0;
    }

    char line[MAX_LINE_LENGTH];
    double newMoney = 0.0;
    bool found = false;

    while(fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, "\n")] = '\0';

        char currentUser[MAX_USERNAME_LENGTH];
        char currentPassword[MAX_PASSWORD_LENGTH];
        char currentAddress[MAX_ADDRESS_LENGTH];
        char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
        double currentMoney;

        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
        if(strcmp(currentCreditCard, creditCard) == 0) // Se trova una corrispondenza con la carta di credito
        {
            newMoney = currentMoney;
            found = true;
            break;
        }
    }
    fclose(file);

    if(!found) // Se non viene trovata una corrispondenza con la carta di credito
    {
        newMoney = 0.0;
    }
    return newMoney;
}

// Funzione per visualizzare i dati di un utente
void userProfile(void)
{
	char choice[3];
	char modifyChoice[3];
	
	do
	{
	    FILE *file = fopen("users.csv", "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
	    
	    FILE *tempFile = fopen("temp.csv", "w");
		if(tempFile == NULL)
		{
		    SetColor(4);
		    puts("ERRORE: Impossibile creare il file temporaneo!\n");
		    SetColor(15);
		    system("pause");
		    fclose(file);
		    return;
		}
	
	    system("cls");
	    SetColor(2);
	    printf("Profilo utente di ");
	    SetColor(11);
	    printf("%s\n\n", loggedInUsername);
	    SetColor(15);
	
	    char line[MAX_LINE_LENGTH];
	    bool yesCreditCard = false;
	    
	    while(fgets(line, sizeof(line), file) != NULL)
	    {
	        char profileUsername[MAX_USERNAME_LENGTH];
	        char profilePassword[MAX_PASSWORD_LENGTH];
	        char profileAddress[MAX_ADDRESS_LENGTH];
	        char profileCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
	        double profileMoney;
	
	        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", profileUsername, profilePassword, profileAddress, profileCreditCard, &profileMoney);
	        if(strcmp(profileUsername, loggedInUsername) == 0)
	        {
	            printf("1.Password: %s\n", profilePassword);
	            printf("2.Indirizzo di casa: %s", profileAddress);
	            if(strlen(profileCreditCard) == 0) // Se l'utente non ha una carta di credito
			    {
			    	printf("3.Preferenza di pagamento: Pagamento alla consegna\n");
			    }else
			    {
			        printf("\n3.Preferenza di pagamento: Carta di credito\n");
			        printf("4.Numero carta di credito: %s\n", profileCreditCard);
			        printf("5.Denaro disponibile: %.2lf\n", profileMoney);
			        yesCreditCard = true;
			    }
	            printf("\n");
	        }
	    }
	    rewind(file);
	    
	    printf("Vuoi modificare le impostazioni? (Y/N): ");
	    if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
	    {
	        // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
	        if (choice[strlen(choice) - 1] == '\n')
	        {
	            choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
	        }else
	        {
	                clearInputBuffer();
	        }
	    }
	
	    if(strlen(choice) == 1)
	    {
	        switch(choice[0])
	        {
		        case 'Y':
		        case 'y':
			        {
			            printf("\nInserisci il numero dell'opzione da modificare: ");
			            if(fgets(modifyChoice, sizeof(modifyChoice), stdin) != NULL && strlen(modifyChoice) >= 2) 
				        {
				            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
				            if(modifyChoice[strlen(modifyChoice) - 1] == '\n')
				            {
				                modifyChoice[strlen(modifyChoice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
				            }else
				            {
				                clearInputBuffer();
				            }
				        }
				        
						if(strlen(modifyChoice) == 1)
						{	
							switch(modifyChoice[0])
							{
								case '1':
									{
										system("cls");
										SetColor(2);
										puts("Modifica Password\n");
										SetColor(15);
							        			
							        	char password[MAX_PASSWORD_LENGTH];
							        	char newPassword[MAX_PASSWORD_LENGTH];
							        	while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
													
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
											    printf("%s", "Password attuale: ");
												fgets(password, sizeof(password), stdin);
												password[strcspn(password, "\n")] = '\0';
												if(strlen(password) == 0 || strlen(password) >= MAX_PASSWORD_LENGTH - 1 || sscanf(password, " %*21[^\n]") != 0)
												{
													if(strlen(password) == 0)
													{
														SetColor(4);
														puts("\nERRORE: Password attuale non valida!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
											            remove("temp.csv");
														return;
													}else if(strlen(password) >= MAX_PASSWORD_LENGTH - 1)
													{
														SetColor(4);
														puts("\nERRORE: Hai inserito troppi caratteri!\n");
														SetColor(15);
														system("pause");
														clearInputBuffer();
														fclose(file);
														fclose(tempFile);
											            remove("temp.csv");
														return;
													}
												}
											        	
											    // Controllo degli spazi vuoti e dei punti-virgola nella password attuale
												char *ptrPs = password;
												while(*ptrPs != '\0')
												{
													if(*ptrPs == ' ' || *ptrPs == ';')
													{
														SetColor(4);
														puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella password attuale!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
											            remove("temp.csv");
														return;
													}
													ptrPs++;
												}
												
												// Controlla se la password attuale corrisponde alla password presente nel file	
												if(strcmp(currentPassword, password) != 0)
												{
													SetColor(4);
													puts("\nERRORE: La password attuale non � corretta!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
											    
											    printf("%s", "Nuova password (max 20): ");
											    fgets(newPassword, sizeof(newPassword), stdin);
											    newPassword[strcspn(newPassword, "\n")] = '\0';
											    if(strlen(newPassword) == 0 || strlen(newPassword) >= MAX_PASSWORD_LENGTH - 1 || sscanf(newPassword, " %*21[^\n]") != 0)
											    {
											        if(strlen(newPassword) == 0)
											        {
											        	SetColor(4);
											            puts("\nERRORE: Password non valida!\n");
											            SetColor(15);
											            system("pause");
											            fclose(file);
											            fclose(tempFile);
											            remove("temp.csv");
											            return;
											        }else if(strlen(newPassword) >= MAX_PASSWORD_LENGTH - 1)
											        {
											            SetColor(4);
											            puts("\nERRORE: Hai inserito troppi caratteri!\n");
											            SetColor(15);
											            system("pause");
											            clearInputBuffer();
											            fclose(file);
											            fclose(tempFile);
											            remove("temp.csv");
											            return;
											        }
											    }
											    
											    // Controllo degli spazi vuoti e dei punti-virgola nella nuova password
												char *ptrNps = newPassword;
												while(*ptrNps != '\0')
												{
													if(*ptrNps == ' ' || *ptrNps == ';')
													{
														SetColor(4);
														puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella nuova password!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
											            remove("temp.csv");
														return;
													}
													ptrNps++;
												}
											    
											    // Controlla se la nuova password � identica alla password attuale
											    if(strcmp(currentPassword, newPassword) == 0)
												{
													SetColor(4);
													puts("\nERRORE: La nuova password non pu� essere uguale a quella attuale!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
													    
												if(!yesCreditCard) // Se l'utente non ha una carta di credito
												{
											        fprintf(tempFile, "%s;%s;%s\n", currentUser, newPassword, currentAddress);
												}else
												{
												    fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, newPassword, currentAddress, currentCreditCard, currentMoney);
												}
											}else
											{
											    fprintf(tempFile, "%s\n", line);
											}
										}
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										SetColor(10);
										puts("\nPassword modificata correttamente!\n");
										SetColor(15);
										system("pause");
									}
					        		break;
					        		
				        		case '2':
				        			{
				        				system("cls");
										SetColor(2);
										puts("Modifica Indirizzo di casa\n");
										SetColor(15);
										
										char newAddress[MAX_ADDRESS_LENGTH];
							        	while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
											
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
											    printf("%s", "Nuovo indirizzo di casa (max 100): ");
											    fgets(newAddress, sizeof(newAddress), stdin);
											    newAddress[strcspn(newAddress, "\n")] = '\0';
											    whiteSpaceRemover(newAddress);
											    if(strlen(newAddress) == 0 || strlen(newAddress) >= MAX_ADDRESS_LENGTH - 1 || sscanf(newAddress, " %*101[^\n]") != 0)
											    {
											        if(strlen(newAddress) == 0)
											        {
											            SetColor(4);
											            puts("\nERRORE: Indirizzo di casa non valido!\n");
											            SetColor(15);
											            system("pause");
											            fclose(file);
											            fclose(tempFile);
											            remove("temp.csv");
											            return;
											        }else if(strlen(newAddress) >= MAX_ADDRESS_LENGTH - 1)
											        {
											            SetColor(4);
											            puts("\nERRORE: Hai inserito troppi caratteri!\n");
											            SetColor(15);
											            system("pause");
											            clearInputBuffer();
											            fclose(file);
											            fclose(tempFile);
											            remove("temp.csv");
											            return;
											        }
											    }
											    
											    // Controllo dei punti-virgola nel nuovo indirizzo di casa
												char *ptrNad = newAddress;
												while(*ptrNad != '\0')
												{
													if(*ptrNad == ';')
													{
														SetColor(4);
														puts("\nERRORE: I punti-virgola non sono consentiti nel nuovo indirizzo di casa!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
											            remove("temp.csv");
														return;
													}
													ptrNad++;
												}
												
												// Controlla se il nuovo indirizzo di casa � identico all'indirizzo di casa attuale
												if(strcmp(currentAddress, newAddress) == 0)
												{
													SetColor(4);
													puts("\nERRORE: Il nuovo indirizzo di casa non pu� essere uguale a quello attuale!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
												
												if(!yesCreditCard) // Se l'utente non ha una carta di credito
												{
											        fprintf(tempFile, "%s;%s;%s\n", currentUser, currentPassword, newAddress);
												}else
												{
												    fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, newAddress, currentCreditCard, currentMoney);
												}
											}else
											{
												fprintf(tempFile, "%s\n", line);
											}
										}
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										SetColor(10);
										puts("\nIndirizzo di casa modificato correttamente!\n");
										SetColor(15);
										system("pause");
									}
									break;
									
								case '3':
									{
										system("cls");
										SetColor(2);
										puts("Modifica preferenza di pagamento\n");
										SetColor(15);
										
										char newCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
							        	while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
											
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
											    char choicePreference[3];
												char input[100]; // Imposta una certa dimensione per l'inserimento del denaro
												
												printf("Nuova preferenza di pagamento:\n1.Pagamento alla consegna\n"
													    "2.Carta di credito\n\nInserisci il numero in base alla tua scelta: ");
												if(fgets(choicePreference, sizeof(choicePreference), stdin) != NULL && strlen(choicePreference) >= 2)
												{
													// Verifica se l'ultimo carattere inserito � un carattere di nuova linea
													if(choicePreference[strlen(choicePreference) - 1] == '\n')
													{
													    choicePreference[strlen(choicePreference) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
													}else
													{
													    clearInputBuffer();
													}
												}
												
												if(strlen(choicePreference) == 1)
												{
													if(choicePreference[0] == '1')
													{
														if(strlen(currentCreditCard) == 0)
														{
															SetColor(4);
															puts("\nERRORE: La nuova preferenza di pagamento non pu� essere uguale a quella attuale!\n");
															SetColor(15);
															system("pause");
															fclose(file);
															fclose(tempFile);
															remove("temp.csv");
															return;
														}
														fprintf(tempFile, "%s;%s;%s\n", currentUser, currentPassword, currentAddress);
													}else if(choicePreference[0] == '2')
													{
														if(strlen(currentCreditCard) == 16)
														{
															SetColor(4);
															puts("\nERRORE: La nuova preferenza di pagamento non pu� essere uguale a quella attuale!\n");
															SetColor(15);
															system("pause");
															fclose(file);
															fclose(tempFile);
															remove("temp.csv");
															return;
														}
														
														printf("\nNumero carta di credito (max 16): ");
														fgets(newCreditCard, sizeof(newCreditCard), stdin);
														newCreditCard[strcspn(newCreditCard, "\n")] = '\0';
														if(strlen(newCreditCard) == 0 || strlen(newCreditCard) >= MAX_CREDIT_CARD_LENGTH - 1 || strlen(newCreditCard) < MAX_CREDIT_CARD_LENGTH - 2 || sscanf(newCreditCard, " %*17[^\n]") != 0)
														{
															if(strlen(newCreditCard) == 0)
															{
																SetColor(4);
																puts("\nERRORE: Carta di credito non valida!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}else if(strlen(newCreditCard) >= MAX_CREDIT_CARD_LENGTH - 1)
															{
																SetColor(4);
																puts("\nERRORE: Lunghezza carta di credito non valida!\n");
																SetColor(15);
																system("pause");
																clearInputBuffer();
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}else if(strlen(newCreditCard) < MAX_CREDIT_CARD_LENGTH - 2)
															{
																SetColor(4);
																puts("\nERRORE: Lunghezza carta di credito non valida!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}
														}
															
														// Controllo degli spazi vuoti e dei punti-virgola nella carta di credito
														char *ptrCc = newCreditCard;
														while(*ptrCc != '\0')
														{
															if(*ptrCc == ' ' || *ptrCc == ';')
															{
																SetColor(4);
																puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella carta di credito!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}
															ptrCc++;
														}
															
														// Controllo dell'inserimento di soli numeri nella carta di credito
														int i;
														for(i = 0; i < strlen(newCreditCard); i++)
														{
															if(!isdigit(newCreditCard[i]))
															{
																SetColor(4);
																puts("\nERRORE: La carta di credito deve contenere solo numeri!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}
														}
														
														double newMoney = getMoneyCreditCard(newCreditCard);
														
														if(newMoney == 0.0) // Se la carta di credito non corrisponde a nessuna carta nel file
														{
															printf("%s", "Denaro presente nella carta di credito (max 999999,99): ");
															fgets(input, sizeof(input), stdin);
															if(strlen(input) <= 1)
															{
																SetColor(4);
																puts("\nERRORE: Nessun dato inserito!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}else if(sscanf(input, "%lf", &newMoney) != 1 || strchr(input, ' ') != NULL)
															{
																SetColor(4);
																puts("\nERRORE: Denaro carta di credito non valido!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}else if(newMoney < 0.0 || newMoney > 999999.99)
															{
																SetColor(4);
																puts("\nERRORE: Il denaro inserito � insufficiente o troppo elevato!\n");
																SetColor(15);
																system("pause");
																fclose(file);
																fclose(tempFile);
													        	remove("temp.csv");
																return;
															}
														}
														fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, currentAddress, newCreditCard, newMoney);
													}else
													{
														SetColor(4);
														puts("ERRORE: Scelta non valida. Riprova.\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
														remove("temp.csv");
														return;
													}
												}else
												{
													SetColor(4);
													puts("ERRORE: Scelta non valida. Riprova.\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
											}else
											{
											    fprintf(tempFile, "%s\n", line);
											}
										}
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										SetColor(10);
										puts("\nPreferenza di pagamento modificata con successo!\n");
										SetColor(15);
										system("pause");
									}
									break;
									
								case '4':
									if(yesCreditCard)
									{
										system("cls");
										SetColor(2);
										puts("Modifica Carta di credito\n");
										SetColor(15);
										
						                char newCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
						                double newMoney;
							        	while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
											
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{	
											    printf("%s", "Nuovo numero carta di credito (max 16): ");
												fgets(newCreditCard, sizeof(newCreditCard), stdin);
												newCreditCard[strcspn(newCreditCard, "\n")] = '\0';
												if(strlen(newCreditCard) == 0 || strlen(newCreditCard) >= MAX_CREDIT_CARD_LENGTH - 1 || strlen(newCreditCard) < MAX_CREDIT_CARD_LENGTH - 2 || sscanf(newCreditCard, " %*17[^\n]") != 0)
												{
													if(strlen(newCreditCard) == 0)
													{
														SetColor(4);
														puts("\nERRORE: Nuova carta di credito non valida!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
													    remove("temp.csv");
														return;
													}else if(strlen(newCreditCard) >= MAX_CREDIT_CARD_LENGTH - 1)
													{
														SetColor(4);
														puts("\nERRORE: Lunghezza nuova carta di credito non valida!\n");
														SetColor(15);
														system("pause");
														clearInputBuffer();
														fclose(file);
														fclose(tempFile);
													    remove("temp.csv");
														return;
													}else if(strlen(newCreditCard) < MAX_CREDIT_CARD_LENGTH - 2)
													{
														SetColor(4);
														puts("\nERRORE: Lunghezza nuova carta di credito non valida!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
													    remove("temp.csv");
														return;
													}
												}
												
												// Controllo degli spazi vuoti e dei punti-virgola nella nuova carta di credito
												char *ptrCc = newCreditCard;
												while(*ptrCc != '\0')
												{
													if(*ptrCc == ' ' || *ptrCc == ';')
													{
														SetColor(4);
														puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nella nuova carta di credito!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
													    remove("temp.csv");
														return;
													}
													ptrCc++;
												}
													
												// Controllo dell'inserimento di soli numeri nella carta di credito
												int i;
												for(i = 0; i < strlen(newCreditCard); i++)
												{
													if(!isdigit(newCreditCard[i]))
													{
														SetColor(4);
														puts("\nERRORE: La nuova carta di credito deve contenere solo numeri!\n");
														SetColor(15);
														system("pause");
														fclose(file);
														fclose(tempFile);
													    remove("temp.csv");
														return;
													}
												}
												
												// Controlla se la nuova carta di credito � identica alla carta di credito attuale	
												if(strcmp(currentCreditCard, newCreditCard) == 0)
												{
													SetColor(4);
													puts("\nERRORE: La nuova carta di credito non pu� essere uguale a quello attuale!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
												
												double newMoney = getMoneyCreditCard(newCreditCard);
												fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, currentAddress, newCreditCard, newMoney);
											}else
											{
												fprintf(tempFile, "%s\n", line);
											}
										}
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										 
										SetColor(10);
										puts("\nCarta di credito modificata con successo!\n");
										SetColor(15);
										system("pause");
									}else
									{
										fclose(file);
										fclose(tempFile);
										remove("temp.csv");
										errorChoice();
									}
									break;
												
								case '5':
									if(yesCreditCard)
									{
										system("cls");
										SetColor(2);
										puts("Modifica Denaro\n");
										SetColor(15);
											
										double newMoney;
										char input[100]; // Imposta una certa dimensione per l'inserimento del denaro
							        	while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
											
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
											    printf("%s", "Nuovo denaro presente nella carta di credito (max 999999,99): ");
												fgets(input, sizeof(input), stdin);
												if(strlen(input) <= 1)
												{
													SetColor(4);
													puts("\nERRORE: Nessun dato inserito!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}else if(sscanf(input, "%lf", &newMoney) != 1 || strchr(input, ' ') != NULL)
												{
													SetColor(4);
													puts("\nERRORE: Nuovo denaro carta di credito non valido!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}else if(newMoney < 0.0 || newMoney > 999999.99)
												{
													SetColor(4);
													puts("\nERRORE: Il nuovo denaro inserito � insufficiente o troppo elevato!\n");
													SetColor(15);
													system("pause");
													fclose(file);
													fclose(tempFile);
													remove("temp.csv");
													return;
												}
												
												// Aggiorna il denaro su tutte le carte di credito corrispondenti
												rewind(file);
												while(fgets(line, sizeof(line), file) != NULL)
												{
													line[strcspn(line, "\n")] = '\0';
													
													char username[MAX_USERNAME_LENGTH];
													char password[MAX_PASSWORD_LENGTH];
													char address[MAX_ADDRESS_LENGTH];
													char creditCard[MAX_CREDIT_CARD_LENGTH] = "";
													double money;
													
													sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", username, password, address, creditCard, &money);
													if(strcmp(creditCard, currentCreditCard) == 0)
													{
													    money = newMoney;
													}
													
													if(strlen(creditCard) == 16)
													{
														fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", username, password, address, creditCard, money);
													}else
													{
														fprintf(tempFile, "%s;%s;%s\n", username, password, address);
													}
												}
													
												// Copia le rimanenti righe nel file temporaneo
												while(fgets(line, sizeof(line), file) != NULL)
												{
													fprintf(tempFile, "%s", line);
												}
											}
										}
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										SetColor(10);
										puts("\nDenaro modificato correttamente!\n");
										SetColor(15);
										system("pause");
									}else
									{
										fclose(file);
										fclose(tempFile);
										remove("temp.csv");
										errorChoice();
									}
									break;
								
								default:
									fclose(file);
									fclose(tempFile);
									remove("temp.csv");
						            errorChoice();
					        }
				        }else
						{
							fclose(file);
							fclose(tempFile);
							remove("temp.csv");
				            errorChoice();
				        }
				    }
					break;
		
		        case 'N':
		        case 'n':
		        	fclose(file);
					fclose(tempFile);
					remove("temp.csv");
		            break;
		
		        default:
		        	fclose(file);
					fclose(tempFile);
					remove("temp.csv");
		            errorChoice();
	        }
	    }else
	    {
	    	fclose(file);
			fclose(tempFile);
			remove("temp.csv");
	        errorChoice();
	    }
	}while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione che salva il contenuto del carrello di un utente
int saveCartToFile(int cart_index)
{
	char filename[40];
    sprintf(filename, "%s_cart.csv", loggedInUsername);
    
    FILE *file = fopen(filename, "w");
    if(file == NULL)
	{
        SetColor(4);
        puts("ERRORE: Impossibile creare il file del carrello!\n");
        SetColor(15);
        system("pause");
        return 0;
    }
	
	int i;
    for(i = 0; i < cart_index; i++)
	{
        fprintf(file, "%hu;%s;%hu;%.2lf\n", i + 1, product_cart[i].name, product_cart[i].amount, product_cart[i].price);
    }
    fclose(file);
    return 1; // Salvattaggio avvenuto con successo
}

// Funzione che permette di inserire i prodotti nel carrello dell'utente
void addCart(int *cart_index, const char *category, bool showZeroQuantity)
{
    char choice[3];
	
	// Carica il contenuto del carrello dal file, se presente
	char cartFile[40];
    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
    
    FILE *cart = fopen(cartFile, "r");
    if(cart != NULL)
	{
        char line[MAX_LINE_LENGTH];
        while (fgets(line, sizeof(line), cart) != NULL)
		{
            line[strcspn(line, "\n")] = '\0';

            unsigned short int currentId;
            char currentName[MAX_NAME_LENGTH];
            unsigned short int currentAmount;
            double currentPrice;

            sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
            
			// Verifica se il prodotto � gi� presente nel carrello
            int cartItemIndex = -1;
            unsigned short int newId = 1;
            int i;
            for(i = 0; i < *cart_index; i++)
            {
                if(strcmp(product_cart[i].name, currentName) == 0)
                {
                    cartItemIndex = i;
                    break;
                }
            }

            if(cartItemIndex == -1)
            {
            	if(currentAmount > 0)
				{
					// Prodotto non presente nel carrello, aggiungi il prodotto al carrello
			        product_cart[*cart_index].id = currentId;
                    strncpy(product_cart[*cart_index].name, currentName, sizeof(product_cart[*cart_index].name));
                    product_cart[*cart_index].amount = currentAmount;
                    product_cart[*cart_index].price = currentAmount * (currentPrice / currentAmount);
                    (*cart_index)++;
				}
            }
        }
        fclose(cart);
    }
    
    do
    {
    	char filename[20];
    	sprintf(filename, "%s_products.csv", category);
		
	    FILE *file = fopen(filename, "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
		
		FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    
	    showCatalogue(category, showZeroQuantity); // Mostra il catalogo prodotti di una delle 5 categorie
	    
	    // Controlla se il file contiene prodotti
        fseek(file, 0, SEEK_END);
        int file_size = ftell(file);
        
		if (file_size == 0)
        {
            SetColor(4);
            puts("Non ci sono prodotti da aggiugere al carrello!\n");
            SetColor(15);
            system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
        }
	    rewind(file);
	    
	    SetColor(2);
	    puts("Aggiungi prodotto al carrello\n");
	    SetColor(15);
        
        // Verifica se il carrello ha raggiunto la capacit� massima
        if(*cart_index >= 100)
	    {
	        SetColor(4);
	        puts("ERRORE: Il carrello � pieno!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
            fclose(tempFile);
            remove("temp.csv");
	        return;
	    }
        
		char input[100]; // Imposta una certa dimensione per l'inserimento dell'ID e della quantit�
	    unsigned short int id_to_add;
	    
		printf("%s", "Inserisci l'ID del prodotto da acquistare: ");
	    fgets(input, sizeof(input), stdin);
	    if(strlen(input) <= 1)
		{
	        SetColor(4);
	        puts("\nERRORE: Nessun ID inserito!\n");
	        SetColor(15);
	        system("pause");
			fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
	    }else if(sscanf(input, "%hu", &id_to_add) != 1 || strchr(input, ' ') != NULL)
		{
	        SetColor(4);
	        puts("\nERRORE: ID prodotto non valido!\n");
	        SetColor(15);
	        system("pause");
			fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
		}
        
        char line[MAX_LINE_LENGTH];
        bool foundProduct = false;
        
        while(fgets(line, sizeof(line), file) != NULL)
        {
        	line[strcspn(line, "\n")] = '\0';
        	
            unsigned short int currentId;
	        char currentName[MAX_NAME_LENGTH];
	        unsigned short int currentAmount;
	        double currentPrice;
	
	        sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
            if(currentId == id_to_add && currentAmount != 0)
            {	
            	foundProduct = true;
            	
				unsigned short int quantity;
		        printf("Inserire la quantit� da acquistare (max %hu): ", currentAmount);
		        fgets(input, sizeof(input), stdin);
				if(strlen(input) <= 1)
				{
			        SetColor(4);
			        puts("\nERRORE: Nessun quantit� inserita!\n");
			        SetColor(15);
			        system("pause");
					fclose(file);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
			    }else if(sscanf(input, "%hu", &quantity) != 1 || strchr(input, ' ') != NULL)
				{
			        SetColor(4);
			        puts("\nERRORE: Quantit� prodotto non valida!\n");
			        SetColor(15);
			        system("pause");
					fclose(file);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
			    }else if(quantity > currentAmount)
		        {
		            SetColor(4);
		            puts("\nERRORE: Quantit� non disponibile.\n");
		            SetColor(15);
		            system("pause");
		            fclose(file);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
				}
				
                // Verifica se il prodotto � gi� presente nel carrello
		        int cartItemIndex = -1;
		        int i;
				for(i = 0; i < *cart_index; i++)
		        {
		            if(strcmp(product_cart[i].name, currentName) == 0)
		            {
		                cartItemIndex = i;
		                break;
		            }
		        }
		
		        if(cartItemIndex != -1)
		        {
		        	if(quantity > 0)
					{
						// Prodotto gi� presente nel carrello, aggiorna la quantit� e il prezzo
				        product_cart[cartItemIndex].amount += quantity;
		    			product_cart[cartItemIndex].price += quantity * currentPrice;	
					}	
		        }else
		        {
		        	if(quantity > 0)
					{
						// Prodotto non presente nel carrello, aggiunge il prodotto al carrello
				        product_cart[*cart_index].id = *cart_index + 1;
						strncpy(product_cart[*cart_index].name, currentName, sizeof(product_cart[*cart_index].name));
						product_cart[*cart_index].amount = quantity;
						product_cart[*cart_index].price = quantity * currentPrice;
						(*cart_index)++;
					}	
		        }
		        currentAmount -= quantity;
                fprintf(tempFile, "%hu;%s;%hu;%.2lf\n", currentId, currentName, currentAmount, currentPrice);
            }else
            {
                fprintf(tempFile, "%s\n", line);
            }
        }
        fclose(file);
        fclose(tempFile);
        
        remove(filename);
	    rename("temp.csv", filename);
		
		// Gestisce gli errori
        if(!foundProduct)
	    {
	        SetColor(4);
	        puts("\nERRORE: Prodotto non disponibile nel Catalogo!\n");
	        SetColor(15);
	        system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
	        return;
	    }
		
		saveCartToFile(*cart_index); // Salva il carrello
        printf("Vuoi continuare ad acquistare? (Y/N): ");
        if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
    }while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione che mostra il contenuto del carrello
void showCart(int *cart_index)
{
    system("cls");
	double total = 0.0;
	bool emptyCart = true;
    
	SetColor(2);
    puts("Resoconto acquisti\n");
   	SetColor(11);
	printf("+----------------+--------------------------------+------------------+------------+\n"
		   "|       ID       |              Nome              |     Quantit�     |   Prezzo   |\n"
		   "+----------------+--------------------------------+------------------+------------+\n");
	
	// Carica il contenuto del carrello dal file dell'utente, se presente
    char cartFile[40];
    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
    FILE *cart = fopen(cartFile, "r");
    if(cart != NULL)
	{
        char line[MAX_LINE_LENGTH];
        while(fgets(line, sizeof(line), cart) != NULL)
		{
            line[strcspn(line, "\n")] = '\0';

            unsigned short int currentId;
            char currentName[MAX_NAME_LENGTH];
            unsigned short int currentAmount;
            double currentPrice;

            sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
			printf("+----------------+--------------------------------+------------------+------------+\n");
	        printf("| %-14hu | %-30s | %-16hu | %.2lf\t  |\n", currentId, currentName, currentAmount, currentPrice);
	        printf("+----------------+--------------------------------+------------------+------------+\n");
	        total += currentPrice;
	        emptyCart = false; // Il carrello non � vuoto
        }
        fclose(cart);
    }
    
    // Gestisce gli errori
	if(emptyCart)
	{
        SetColor(4);
        puts("\nIl carrello � vuoto!\n");
        SetColor(15);
        fclose(cart);
    }else
	{
	    SetColor(15);
    	printf("\nTotale acquisti: %.2lf\n\n", total);
	}
}

// Funzione che permette di utilizzare "addCart" con le varie categorie
void cartSelection(int *cart_index, bool showZeroQuantity)
{
    char choice[3];
    
    do
	{
		showProducts();
	    if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
	    {
	        // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
	    }
	
	    if(strlen(choice) == 1)
	    {
	        switch(choice[0])
	        {
		        case '0':
		            break;
		
		        case '1':
		            addCart(cart_index, "Shirts", showZeroQuantity);
		            break;
		
		        case '2':
		            addCart(cart_index, "Jeans", showZeroQuantity);
					break;
		
		        case '3':
		            addCart(cart_index, "Coat", showZeroQuantity);
					break;
		
		        case '4':
		            addCart(cart_index, "Shoes", showZeroQuantity);
					break;
		
		        case '5':
		            addCart(cart_index, "Winter", showZeroQuantity);
					break;
		
		        default:
		            errorChoice();
	        }
	    }
	    else
	    {
	        errorChoice();
	    }
	}while(choice[0] != '0');
}

// Funzione che modifica i prodotti nel carrello
void editCart(int *cart_index)
{
	char choice[3];
    char category[5][20] = {"Shirts", "Jeans", "Coat", "Shoes", "Winter"};
    
	do
	{
		char cartFile[40];
	    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
	    
		FILE *cart = fopen(cartFile, "r");
		if(cart == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file del carrello!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
		
		FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        return;
	    }
	    
	    showCart(cart_index); // Mostra il contenuto del carrello
	    
	    // Verifica se il carrello � vuoto
	    fseek(cart, 0, SEEK_END);
	    if(ftell(cart) == 0)
	    {
	        system("pause");
	        fclose(cart);
	        fclose(tempFile);
	        remove("temp.csv");
	        return;
	    }
	    fseek(cart, 0, SEEK_SET);
	    
	    SetColor(2);
	    puts("Modifica carrello\n");
	    SetColor(4);
	    printf("%s", "ATTENZIONE: ");
	    SetColor(15);
	    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi!\n\n");
	    
		char input[100]; // Imposta una certa dimensione per l'inserimento dell'ID e della quantit�
	    unsigned short int id_to_change;
	    
		printf("%s", "Inserisci l'ID del prodotto da modificare: ");
		fgets(input, sizeof(input), stdin);
	    if(strlen(input) <= 1)
		{
	        SetColor(4);
	        puts("\nERRORE: Nessun ID inserito!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }else if(sscanf(input, "%hu", &id_to_change) != 1 || strchr(input, ' ') != NULL)
		{
	        SetColor(4);
	        puts("\nERRORE: ID prodotto non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }
		
	    char line[MAX_LINE_LENGTH];
	    bool foundProduct = false;
	    
	    while(fgets(line, sizeof(line), cart) != NULL)
	    {
	    	line[strcspn(line, "\n")] = '\0';
	        
			unsigned short int currentId;
	        char currentName[MAX_NAME_LENGTH];
	        unsigned short int currentAmount;
	        double currentPrice;
	        
	        sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
	        if(currentId == id_to_change)
	        {
				foundProduct = true;
				
				unsigned short int newAmount;
		        printf("Inserire la quantit� da eliminare (max %hu): ", currentAmount);
		        fgets(input, sizeof(input), stdin);
				if(strlen(input) <= 1)
				{
			        SetColor(4);
			        puts("\nERRORE: Nessun quantit� inserita!\n");
			        SetColor(15);
			        system("pause");
					fclose(cart);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
			    }else if(sscanf(input, "%hu", &newAmount) != 1 || strchr(input, ' ') != NULL)
				{
			        SetColor(4);
			        puts("\nERRORE: Quantit� prodotto non valida!\n");
			        SetColor(15);
			        system("pause");
					fclose(cart);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
			    }else if(newAmount > currentAmount)
		        {
		            SetColor(4);
		            puts("\nERRORE: Quantit� non disponibile.\n");
		            SetColor(15);
		            system("pause");
		            fclose(cart);
		            fclose(tempFile);
		            remove("temp.csv");
		            return;
				}
				
			    int i;
                for (i = 0; i < 5; i++)
                {
                    char filename[20];
                    sprintf(filename, "%s_products.csv", category[i]);

                    FILE *file = fopen(filename, "r");
                    if (file == NULL)
                    {
                        SetColor(4);
                        puts("ERRORE: Impossibile aprire il file!\n");
                        SetColor(15);
                        system("pause");
                        fclose(cart);
			            fclose(tempFile);
			            remove("temp.csv");
                        return;
                    }

                    while(fgets(line, sizeof(line), file) != NULL)
                    {
                        line[strcspn(line, "\n")] = '\0';

                        unsigned short int productId;
                        char productName[MAX_NAME_LENGTH];
                        unsigned short int productAmount;
                        double productPrice;

                        sscanf(line, "%hu;%[^;];%hu;%lf", &productId, productName, &productAmount, &productPrice);
                        if(strcmp(productName, currentName) == 0)
                        {
                            // Verifica se il prodotto � presente nei vari file
                            int productItemIndex = -1;
                            int j;
                            for(j = 0; j < *cart_index; j++)
                            {
                                if(list_product[j].id == id_to_change && strcmp(list_product[j].name, currentName) == 0)
                                {
                                    productItemIndex = j;
                                    break;
                                }
                            }

                            if(productItemIndex != -1)
                            {
                                // Prodotto gi� presente nel file, aggiorna la quantit�
                                list_product[productItemIndex].amount += newAmount;
                            }
                            
                            // Aggiorna la quantit� nel file della categoria corrispondente
                            productAmount += newAmount;
                            fseek(file, 0, SEEK_SET);
                            FILE *tempCategoryFile = fopen("temp_category.csv", "w");
                            if(tempCategoryFile == NULL)
                            {
                                SetColor(4);
                                puts("ERRORE: Impossibile creare il file temporaneo!\n");
                                SetColor(15);
                                system("pause");
                                fclose(cart);
                                fclose(tempFile);
                                fclose(file);
                                remove("temp.csv");
                                return;
                            }
                            
                            while(fgets(line, sizeof(line), file) != NULL)
                            {
                                line[strcspn(line, "\n")] = '\0';
                                unsigned short int categoryId;
                                char categoryName[MAX_NAME_LENGTH];
                                unsigned short int categoryAmount;
                                double categoryPrice;
                                
                                sscanf(line, "%hu;%[^;];%hu;%lf", &categoryId, categoryName, &categoryAmount, &categoryPrice);
                                if(strcmp(categoryName, productName) == 0)
                                {
                                    fprintf(tempCategoryFile, "%hu;%s;%hu;%.2lf\n", categoryId, categoryName, productAmount, categoryPrice);
                                }else
                                {
                                    fprintf(tempCategoryFile, "%hu;%s;%hu;%.2lf\n", categoryId, categoryName, categoryAmount, categoryPrice);
                                }
                            }
                            fclose(file);
                            fclose(tempCategoryFile);
                            
                            remove(filename);
                            rename("temp_category.csv", filename);
                        }
                    }
                    fclose(file);
                }
			    
			    currentAmount -= newAmount;
			    if(currentAmount == 0)
				{
					// Modifica gli ID dei prodotti successivi
			        unsigned short int updatedId = id_to_change;
			        while(fgets(line, sizeof(line), cart) != NULL)
			        {
			            line[strcspn(line, "\n")] = '\0';
			
			            unsigned short int currentId;
			            char currentName[MAX_NAME_LENGTH];
			            unsigned short int currentAmount;
			            double currentPrice;
			
			            sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
			            if (currentId != id_to_change)
					    {
					        fprintf(tempFile, "%hu;%s;%hu;%.2lf\n", updatedId, currentName, currentAmount, currentPrice);
					        updatedId++; // Incrementa l'ID
					    }
			        }
				}else
				{
					currentPrice = currentAmount * (currentPrice / (currentAmount + newAmount));
					fprintf(tempFile, "%hu;%s;%hu;%.2lf\n", currentId, currentName, currentAmount, currentPrice);
				}
	        }else
	        {
	            fprintf(tempFile, "%s\n", line);
	        }
	    }
	    fclose(cart);
	    fclose(tempFile);
	
	    remove(cartFile);
	    rename("temp.csv", cartFile);
		
		// Gestisce gli errori
	    if(!foundProduct)
	    {
	        SetColor(4);
	        puts("\nERRORE: Prodotto non trovato!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        fclose(tempFile);
	        remove("temp.csv");
	        return;
	    }else
		{
			showCart(cart_index); // Mostra il contenuto del carrello
			SetColor(10);
		    puts("Carrello modificato correttamente!\n");
		    SetColor(15);
		}
		
		printf("Vuoi continuare a modificare prodotti? (Y/N): ");
    	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if (choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
	}while(choice[0] == 'Y' || choice[0] == 'y');
}

// Funzione che effettua un confronto con il codice del coupon
double getDiscount(const char *couponCode)
{
    FILE *file = fopen("coupon.csv", "r");
    if (file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return 0.0;
    }

    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char code[MAX_CODE_LENGTH];
        unsigned short int discount;
        
        sscanf(line, "%[^;];%hu", code, &discount);
        if(strcmp(code, couponCode) == 0)
        {
            fclose(file);
            return (double) discount;
        }
    }
    fclose(file);
    return 0.0; // Se il coupon non viene trovato, restituisce uno sconto di 0
}

// Funzione che calcola il prezzo totale del carrello
double getTotalPrice(void)
{
    double total = 0.0;

    char cartFile[40];
    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
    FILE *cart = fopen(cartFile, "r");
    if(cart == NULL)
    {
    	SetColor(4);
        puts("ERRORE: Impossibile aprire il file del carrello!\n");
        SetColor(15);
        system("pause");
        return 0.0;
    }
	
	char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), cart) != NULL)
    {
        unsigned short int currentId;
        char currentName[MAX_NAME_LENGTH];
        unsigned short int currentAmount;
        double currentPrice;
        
		sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
        total += currentPrice;
    }
    fclose(cart);
    return total;
}

// Funzione che calcola la quantit� totale del carrello
unsigned short int getTotalQuantity(void)
{
    unsigned short int quantity = 0;

    char cartFile[40];
    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
    FILE *cart = fopen(cartFile, "r");
    if(cart == NULL)
    {
    	SetColor(4);
        puts("ERRORE: Impossibile aprire il file del carrello!\n");
        SetColor(15);
        system("pause");
        return 0;
    }
	
	char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), cart) != NULL)
    {
        unsigned short int currentId;
        char currentName[MAX_NAME_LENGTH];
        unsigned short int currentAmount;
        double currentPrice;
        
		sscanf(line, "%hu;%[^;];%hu;%lf", &currentId, currentName, &currentAmount, &currentPrice);
        quantity += currentAmount;
    }
    fclose(cart);
    return quantity;
}

// Funzione che salva l'ordine dell'utente con il relativo denaro speso e la quantit�
void saveOrder(unsigned short int orderNumber, unsigned short int quantity, double amount)
{
    char filename[45];
    sprintf(filename, "%s_orders.csv", loggedInUsername);
    
    FILE *file = fopen(filename, "a");
    if(file != NULL)
	{
        fprintf(file, "%hu;%hu;%.2lf\n", orderNumber, quantity, amount); // Scrive l'ordine nel file
    }
    fclose(file);
}

// Funzione che aggiorna il denaro di carte di credito identiche
void updateMoney(const char *creditCard, double newMoney)
{
    FILE *file = fopen("users.csv", "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        system("pause");
        return;
    }
    
    FILE *tempFile = fopen("temp.csv", "w");
    if(tempFile == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile creare il file temporaneo!\n");
        SetColor(15);
        system("pause");
        fclose(file);
        return;
    }
	
	char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, "\n")] = '\0';

        char currentUser[MAX_USERNAME_LENGTH];
        char currentPassword[MAX_PASSWORD_LENGTH];
        char currentAddress[MAX_ADDRESS_LENGTH];
        char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
        double currentMoney;

        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
        if(strcmp(currentCreditCard, creditCard) == 0)
        {
            currentMoney = newMoney;
        }

        if(strlen(currentCreditCard) == 0)
        {
            fprintf(tempFile, "%s;%s;%s\n", currentUser, currentPassword, currentAddress);
        }else
        {
            fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, currentAddress, currentCreditCard, currentMoney);
        }
    }
    fclose(file);
    fclose(tempFile);
    
    remove("users.csv");
    rename("temp.csv", "users.csv");
}

// Funzione che effettua l'acquisto dei prodotti all'interno del carrello
void buyProduct(int *cart_index)
{
	char choice[3];
	char modifyChoice[3];
	
	do
	{
		char cartFile[40];
	    sprintf(cartFile, "%s_cart.csv", loggedInUsername);
	    
		FILE *cart = fopen(cartFile, "r");
		if(cart == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file del carrello!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
		
		FILE *file = fopen("users.csv", "r");
	    if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        return;
	    }
	    
	    FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(cart);
	        fclose(file);
	        return;
	    }
	    
	    showCart(cart_index); // Mostra il carrello dell'utente
	    unsigned short int orderNumber = getOrderNumber();
		char creditCard[MAX_CREDIT_CARD_LENGTH] = "";
	    
	    // Verifica se il carrello � vuoto
	    fseek(cart, 0, SEEK_END);
	    if(ftell(cart) == 0)
	    {
	        fclose(cart);
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
	        system("pause");
	        return;
	    }
	    fseek(cart, 0, SEEK_SET);
	    
	    printf("Desideri effettuare l'acquisto? (Y/N): ");
	    if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
	    {
	        // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
	        if(choice[strlen(choice) - 1] == '\n')
	        {
	            choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
	        }else
	        {
	            clearInputBuffer();
	        }
	    }
	
	    if(strlen(choice) == 1)
	    {
	        switch(choice[0])
	        {
	            case 'Y':
	            case 'y':
	            	{
	            		system("cls");
	            		showCart(cart_index);
	            		printf("Vuoi utilizzare un coupon? (Y/N): ");
			            if(fgets(modifyChoice, sizeof(modifyChoice), stdin) != NULL && strlen(modifyChoice) >= 2) 
				        {
				            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
				            if(modifyChoice[strlen(modifyChoice) - 1] == '\n')
				            {
				                modifyChoice[strlen(modifyChoice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
				            }else
				            {
				                clearInputBuffer();
				            }
				        }
				        
						if(strlen(modifyChoice) == 1)
						{	
							switch(modifyChoice[0])
							{
								case 'Y':
								case 'y':
									{
										FILE *couponFile = fopen("coupon.csv", "r");
									    if(couponFile == NULL)
									    {
									        SetColor(4);
									        puts("ERRORE: Impossibile aprire il file!\n");
									        SetColor(15);
									        system("pause");
									        fclose(cart);
									        fclose(file);
									        fclose(tempFile);
	        								remove("temp.csv");
									        return;
									    }
									    
										puts("");
										showDiscountCodes(); // Mostra la lista di codici sconto
										
										// Controlla se il file contiene coupon
								        fseek(couponFile, 0, SEEK_END);
								        int file_size = ftell(couponFile);
								        
										if(file_size == 0)
								        {
								            SetColor(4);
								            puts("Non ci sono coupon da utilizzare!\n");
								            SetColor(15);
								            system("pause");
								            fclose(cart);
								            fclose(file);
								            fclose(couponFile);
								            fclose(tempFile);
								            remove("temp.csv");
								            return;
								        }
									    rewind(couponFile);
										
										double money = 0.0;
										unsigned short int totalProductsSold = 0;
									    unsigned short int totalOrders = 0;
									    double totalRevenue = 0.0;
									    
										char line[MAX_LINE_LENGTH];
										while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
													
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
												strcpy(creditCard, currentCreditCard); // Copia la carta di credito dell'utente attuale
												char code[MAX_CODE_LENGTH];
												
												printf("Inserisci il codice del coupon: ");
											    fgets(code, sizeof(code), stdin);
											    code[strcspn(code, "\n")] = '\0'; // Rimuove il carattere di nuova riga da fgets
											    if(strlen(code) == 0 || strlen(code) >= MAX_CODE_LENGTH - 1 || sscanf(code, " %*8[^\n]") != 0)
												{
													if(strlen(code) == 0)
													{
														SetColor(4);
												        puts("\nERRORE: Codice non valido!\n");
												        SetColor(15);
												        system("pause");
												        fclose(cart);
														fclose(file);
														fclose(couponFile);
														fclose(tempFile);
														remove("temp.csv");
												        return;
												    }else if(strlen(code) >= MAX_CODE_LENGTH - 1)
												    {
												        SetColor(4);
												    	puts("\nERRORE: Hai inserito troppi caratteri!\n");
												        SetColor(15);
												        system("pause");
												        clearInputBuffer();
												        fclose(cart);
														fclose(file);
														fclose(couponFile);
														fclose(tempFile);
														remove("temp.csv");
												        return;
												    }
												}
												
												// Controllo degli spazi vuoti e dei punti-virgola nel codice
												char *ptrCd = code;
												while(*ptrCd != '\0')
												{
												    if(*ptrCd == ' ' || *ptrCd == ';')
													{
												        SetColor(4);
												        puts("\nERRORE: Gli spazi vuoti ed i punti-virgola non sono consentiti nel codice!\n");
												        SetColor(15);
												        system("pause");
												        fclose(cart);
														fclose(file);
														fclose(couponFile);
														fclose(tempFile);
														remove("temp.csv");
												        return;
												    }
												    ptrCd++;
												}
												
												double discount = getDiscount(code); // Confronto il codice inserito
										        double totalPrice = getTotalPrice(); // Calcola il prezzo totale del carrello
										        double discountedPrice = totalPrice * (1.0 - (discount / 100.0)); // Calcola il prezzo con sconto
										        unsigned short int quantity = getTotalQuantity();
										        
												if(strlen(currentCreditCard) == 0)
												{
													printf("\nPrezzo totale: %.2lf\n\n", discountedPrice);
													system("pause");
													system("cls");
										            showShipping(); // Monitora la spedizione
										            SetColor(10);
										            printf("\nPagamento effettuato con successo!\n\n");
										            SetColor(15);
													saveOrder(orderNumber, quantity, discountedPrice); // Salva il numero dell'ordine, la quantit� dei prodotti e il prezzo
										            totalProductsSold += quantity;
										            totalOrders++;
										            totalRevenue += discountedPrice;
										            updateStats(totalProductsSold, totalOrders, totalRevenue, false); // Aggiorna le statistiche
										            
										            // Svuota il carrello dell'utente
						                            fclose(cart);
						                            cart = fopen(cartFile, "w");
						                            if(cart == NULL)
						                            {
						                                SetColor(4);
						                                puts("ERRORE: Impossibile svuotare il carrello!\n");
						                                SetColor(15);
						                                system("pause");
						                                fclose(file);
						                                fclose(couponFile);
						                                fclose(tempFile);
														remove("temp.csv");
						                                return;
						                            }
										            system("pause");
									        	}else
												{   
													printf("Prezzo totale con sconto: %.2lf\n", discountedPrice);
										            if(currentMoney >= discountedPrice)
										            {
										                currentMoney -= discountedPrice; // Diminuisce il denaro disponibile in base all'acquisto
										                money = currentMoney;
														SetColor(10);
											            printf("\nPagamento effettuato con successo!\n");
											            SetColor(15);
										                printf("\nDenaro disponibile rimanente: %.2lf\n\n", currentMoney);
										                system("pause");
														system("cls");
														showShipping(); // Monitora la spedizione
														saveOrder(orderNumber, quantity, discountedPrice); // Salva il numero dell'ordine, la quantit� dei prodotti e il prezzo
														totalProductsSold += quantity;
														totalOrders++;
														totalRevenue += discountedPrice;
														updateStats(totalProductsSold, totalOrders, totalRevenue, false); // Aggiorna le statistiche
														
														// Svuota il carrello dell'utente
							                            fclose(cart);
							                            cart = fopen(cartFile, "w");
							                            if(cart == NULL)
							                            {
							                                SetColor(4);
							                                puts("ERRORE: Impossibile svuotare il carrello!\n");
							                                SetColor(15);
							                                system("pause");
							                                fclose(file);
							                                fclose(couponFile);
							                                fclose(tempFile);
															remove("temp.csv");
							                                return;
							                            }
														puts("");
														system("pause");
										            }else
										            {
										            	SetColor(4);
										                puts("\nErrore: Il denaro � insufficiente nella carta di credito!\n");
										                SetColor(15);
														system("pause");
														fclose(cart);
														fclose(file);
														fclose(couponFile);
														fclose(tempFile);
														remove("temp.csv");
										                return;
										            }
												}
											}
											
											if(strlen(currentCreditCard) == 0)
											{
												fprintf(tempFile, "%s;%s;%s\n", currentUser, currentPassword, currentAddress);
											}else
											{
												fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, currentAddress, currentCreditCard, currentMoney);	
											}
										}
										fclose(cart);
										fclose(file);
										fclose(couponFile);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										updateMoney(creditCard, money); // Aggiorna il denaro di utenti aventi carte di credito identiche
									}
									break;
									
								case 'N':
								case 'n':
									{
										double money = 0.0;
									    unsigned short int totalProductsSold = 0;
									    unsigned short int totalOrders = 0;
									    double totalRevenue = 0.0;
									    
										char line[MAX_LINE_LENGTH];
										while(fgets(line, sizeof(line), file) != NULL)
										{
											line[strcspn(line, "\n")] = '\0';
													
											char currentUser[MAX_USERNAME_LENGTH];
											char currentPassword[MAX_PASSWORD_LENGTH];
											char currentAddress[MAX_ADDRESS_LENGTH];
											char currentCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
											double currentMoney;
											
											sscanf(line, "%[^;];%[^;];%[^;];%[^;];%lf", currentUser, currentPassword, currentAddress, currentCreditCard, &currentMoney);
											if(strcmp(currentUser, loggedInUsername) == 0)
											{
												strcpy(creditCard, currentCreditCard);
												double totalPrice = getTotalPrice();
												unsigned short int quantity = getTotalQuantity();
												
												if(strlen(currentCreditCard) == 0)
												{
													system("cls");
													showShipping(); // Monitora la spedizione
										            SetColor(10);
											        printf("\nPagamento effettuato con successo!\n\n");
											        SetColor(15);
											        saveOrder(orderNumber, quantity, totalPrice); // Salva il numero dell'ordine, la quantit� dei prodotti e il prezzo
											        totalProductsSold += quantity;
											        totalOrders++;
											        totalRevenue += totalPrice;
											        updateStats(totalProductsSold, totalOrders, totalRevenue, false); // Aggiorna le statistiche
											        
											        // Svuota il carrello dell'utente
						                            fclose(cart);
						                            cart = fopen(cartFile, "w");
						                            if(cart == NULL)
						                            {
						                                SetColor(4);
						                                puts("ERRORE: Impossibile svuotare il carrello!\n");
						                                SetColor(15);
						                                system("pause");
						                                fclose(file);
							                            fclose(tempFile);
														remove("temp.csv");
						                                return;
						                            }
											        system("pause");
												}else
												{   
										            printf("Prezzo totale: %.2lf\n", totalPrice);
										            if(currentMoney >= totalPrice)
										            {
										                currentMoney -= totalPrice; // Diminuisce il denaro disponibile in base all'acquisto
										                money = currentMoney;
														SetColor(10);
												        printf("\nPagamento effettuato con successo!\n");
												        SetColor(15);
										                printf("\nDenaro disponibile rimanente: %.2lf\n\n", currentMoney);
										                system("pause");
														system("cls");
														showShipping(); // Monitora la spedizione
														saveOrder(orderNumber, quantity, totalPrice); // Salva il numero dell'ordine, la quantit� dei prodotti e il prezzo
														totalProductsSold += quantity;
														totalOrders++;
														totalRevenue += totalPrice;
														updateStats(totalProductsSold, totalOrders, totalRevenue, false); // Aggiorna le statistiche
														
														// Svuota il carrello dell'utente
							                            fclose(cart);
							                            cart = fopen(cartFile, "w");
							                            if(cart == NULL)
							                            {
							                                SetColor(4);
							                                puts("ERRORE: Impossibile svuotare il carrello!\n");
							                                SetColor(15);
							                                system("pause");
							                                fclose(file);
								                            fclose(tempFile);
															remove("temp.csv");
							                                return;
							                            }
														puts("");
														system("pause");
										            }else
										            {
										                SetColor(4);
										                puts("\nErrore: Il denaro � insufficiente nella carta di credito!\n");
										                SetColor(15);
														system("pause");
														fclose(cart);
														fclose(file);
														fclose(tempFile);
														remove("temp.csv");
										                return;
										            }
												}
											}
											
											if(strlen(currentCreditCard) == 0)
											{
												fprintf(tempFile, "%s;%s;%s\n", currentUser, currentPassword, currentAddress);
											}else
											{
												fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", currentUser, currentPassword, currentAddress, currentCreditCard, currentMoney);	
											}
										}
										fclose(cart);
										fclose(file);
										fclose(tempFile);
										
										remove("users.csv");
										rename("temp.csv", "users.csv");
										
										updateMoney(creditCard, money); // Aggiorna il denaro di utenti aventi carte di credito identiche
									}
									break;
								
								default:
									fclose(cart);
									fclose(file);
									fclose(tempFile);
									remove("temp.csv");
					                errorChoice();
							}
						}else
						{
							fclose(cart);
							fclose(file);
							fclose(tempFile);
							remove("temp.csv");
			                errorChoice();
						}
	            	}
					break;
	
	            case 'N':
	            case 'n':
	            	fclose(cart);
					fclose(file);
					fclose(tempFile);
					remove("temp.csv");
	                break;
	
	            default:
	            	fclose(cart);
					fclose(file);
					fclose(tempFile);
					remove("temp.csv");
	                errorChoice();
	        }
	    }else
	    {
	    	fclose(cart);
			fclose(file);
			fclose(tempFile);
			remove("temp.csv");
	        errorChoice();
	    }
	}while(choice[0] == 'Y' || choice[0] == 'y');
}

void showOrders(void)
{
    char filename[45];
    sprintf(filename, "%s_orders.csv", loggedInUsername);
    
    FILE *file = fopen(filename, "r");
    if(file == NULL)
    {
        SetColor(4);
        puts("ERRORE: Impossibile aprire il file!\n");
        SetColor(15);
        return;
    }
	
	system("cls");
	SetColor(2);
	puts("Lista Ordini\n");
	SetColor(11);
	printf("+----------------+-----------------------+---------------------+\n"
		   "|       ID       |   Quantit� prodotti   |   Totale Acquisto   |\n"
		   "+----------------+-----------------------+---------------------+\n");
	
	// Lettura e stampa dei dati dal file
    char line[MAX_LINE_LENGTH];
    while(fgets(line, sizeof(line), file) != NULL)
    {
        char *token = strtok(line, ";");
	    if(token != NULL)
	    {
	        unsigned short int orderNumber = atoi(token);
			
			token = strtok(NULL, ";");
	        unsigned short int quantity = atoi(token);
			
	        token = strtok(NULL, " ");
	        double price = atof(token);
	
	        printf("+----------------+-----------------------+---------------------+\n");
	        printf("| %-14hu | %-21hu | %.2lf\t       |\n", orderNumber, quantity, price);
	        printf("+----------------+-----------------------+---------------------+\n");
	    }
    }
	fclose(file);
	
	SetColor(15);
    printf("\n");
}

// Funzione che effettua resi e rimborsi
void returnsAndRefunds(void)
{
	char choice[3];
    
	do
	{
		char filename[45];
	    sprintf(filename, "%s_orders.csv", loggedInUsername);
	    
	    FILE *file = fopen(filename, "r");
		if(file == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile aprire il file!\n");
	        SetColor(15);
	        system("pause");
	        return;
	    }
		
		FILE *tempFile = fopen("temp.csv", "w");
	    if(tempFile == NULL)
	    {
	        SetColor(4);
	        puts("ERRORE: Impossibile creare il file temporaneo!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        return;
	    }
	    
	    showOrders(); // Mostra gli ordini totali dell'utente
	    
	    // Controlla se il file contiene prodotti
        fseek(file, 0, SEEK_END);
        int file_size = ftell(file);
        
		if(file_size == 0)
        {
            SetColor(4);
            puts("Non ci sono ordini da restituire!\n");
            SetColor(15);
            system("pause");
            fclose(file);
            fclose(tempFile);
            remove("temp.csv");
            return;
        }
	    rewind(file);
	    
	    SetColor(2);
	    puts("Effettua reso e rimborso\n");
	    SetColor(4);
	    printf("%s", "ATTENZIONE: ");
	    SetColor(15);
	    printf("Gli spazi vuoti ed i punti-virgola non sono consentiti nei vari campi\n\n");
	    
		char input[100]; // Imposta una certa dimensione per l'inserimento dell'ID e della quantit�
	    unsigned short int order_to_remove;
	    
		printf("%s", "Inserisci l'ID dell'ordine: ");
		fgets(input, sizeof(input), stdin);
	    if(strlen(input) <= 1)
		{
	        SetColor(4);
	        puts("\nERRORE: Nessun ID inserito!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }else if(sscanf(input, "%hu", &order_to_remove) != 1 || strchr(input, ' ') != NULL)
		{
	        SetColor(4);
	        puts("\nERRORE: ID ordine non valido!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
			return;
	    }
		
	    char creditCard[MAX_CREDIT_CARD_LENGTH] = "";
	    unsigned short int refundQuantity = 0;
		double refundAmount = 0.0;
	    bool foundOrder = false;
	    
	    char line[MAX_LINE_LENGTH];
	    while(fgets(line, sizeof(line), file) != NULL)
	    {
	    	line[strcspn(line, "\n")] = '\0';
	        
			unsigned short int currentId;
			unsigned short int currentQuantity;
	        double currentPrice;
	        
	        sscanf(line, "%hu;%hu;%lf", &currentId, &currentQuantity, &currentPrice);
	        if(currentId == order_to_remove)
	        {
				foundOrder = true;
				refundAmount = currentPrice;
				refundQuantity = currentQuantity;
	        }else
	        {
	            fprintf(tempFile, "%s\n", line);
	        }
	    }
	    fclose(file);
	    fclose(tempFile);
	
	    remove(filename);
	    rename("temp.csv", filename);
	    
	    updateStats(refundQuantity, 1, refundAmount, true); // Aggiorna le statistiche
	    
	    // Restituisci il denaro all'utente
		FILE *userFile = fopen("users.csv", "r");
		FILE *tempUserFile = fopen("temp_user.csv", "w");
		if(userFile == NULL || tempUserFile == NULL)
		{
		    SetColor(4);
		    puts("ERRORE: Impossibile aprire/creare il file degli utenti!\n");
		    SetColor(15);
		    system("pause");
		    fclose(userFile);
		    fclose(tempUserFile);
		    remove("temp_user.csv");
		    return;
		}
		
		char userLine[MAX_LINE_LENGTH];
		double money = 0.0;
		while(fgets(userLine, sizeof(userLine), userFile) != NULL)
		{
			line[strcspn(line, "\n")] = '\0';
			
		    char profileUsername[MAX_USERNAME_LENGTH];
		    char profilePassword[MAX_PASSWORD_LENGTH];
		    char profileAddress[MAX_ADDRESS_LENGTH];
		    char profileCreditCard[MAX_CREDIT_CARD_LENGTH] = "";
		    double profileMoney;
		
		    sscanf(userLine, "%[^;];%[^;];%[^;];%[^;];%lf", profileUsername, profilePassword, profileAddress, profileCreditCard, &profileMoney);
		    if(strcmp(profileUsername, loggedInUsername) == 0)
			{
				strcpy(creditCard, profileCreditCard);
		        profileMoney += refundAmount;  // Aggiorna il denaro disponibile
		        money = profileMoney;
		    }
		    
		    if(strlen(profileCreditCard) == 0)
			{
				fprintf(tempFile, "%s;%s;%s", profileUsername, profilePassword, profileAddress);
			}else
			{
				fprintf(tempFile, "%s;%s;%s;%s;%.2lf\n", profileUsername, profilePassword, profileAddress, profileCreditCard, profileMoney);	
			}
		}
		fclose(userFile);
		fclose(tempUserFile);
		
		remove("users.csv");
		rename("temp_user.csv", "users.csv");
		
		updateMoney(creditCard, money); // Aggiorna il denaro di utenti aventi carte di credito identiche
		
		// Gestisce gli errori
	    if(!foundOrder)
	    {
	        SetColor(4);
	        puts("\nERRORE: Ordine non trovato!\n");
	        SetColor(15);
	        system("pause");
	        fclose(file);
	        fclose(tempFile);
	        remove("temp.csv");
	        return;
	    }else
		{
			// Modifica gli ID degli ordini successivi
	        FILE *updatedFile = fopen(filename, "r");
	        FILE *tempUpdatedFile = fopen("temp.csv", "w");
	
	        unsigned short int updatedId = 1;
	        while(fgets(line, sizeof(line), updatedFile) != NULL)
	        {
	            line[strcspn(line, "\n")] = '\0';
	
	            unsigned short int currentId;
	            unsigned short int currentQuantity;
	            double currentPrice;
	
	            sscanf(line, "%hu;%hu;%lf", &currentId, &currentQuantity, &currentPrice);
	            fprintf(tempUpdatedFile, "%hu;%hu;%.2lf\n", updatedId, currentQuantity, currentPrice);
	            updatedId++; // Aumenta l'ID
	        }
	        fclose(updatedFile);
	        fclose(tempUpdatedFile);
	
	        remove(filename);
	        rename("temp.csv", filename);
	        
	        showOrders();
			SetColor(10);
			puts("Reso e rimborso avvenuto con successo!\n");
			SetColor(15);
		}
		
		printf("Vuoi continuare a effettuare resi e rimborsi? (Y/N): ");
    	if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2)
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if (choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }

        if(strlen(choice) == 1)
        {
            switch(choice[0])
            {
	            case 'Y':
	            case 'y':
	                break;
	
	            case 'N':
	            case 'n':
	                break;
	
	            default:
	                errorChoice();
            }
        }else
        {
            errorChoice();
        }
	}while(choice[0] == 'Y' || choice[0] == 'y');
}

// Men� della schermata utente
void optionUser(void)
{
	char choice[3];
	int cart_index = 0;
	
    do
	{
	    userScreen();
	    if(fgets(choice, sizeof(choice), stdin) != NULL && strlen(choice) >= 2) 
        {
            // Verifica se l'ultimo carattere inserito � un carattere di nuova linea
            if(choice[strlen(choice) - 1] == '\n')
            {
                choice[strlen(choice) - 1] = '\0'; // Imposta il terminatore di stringa al penultimo carattere
            }else
            {
                clearInputBuffer();
            }
        }
		
		if(strlen(choice) == 1)
		{
		    switch(choice[0])
			{
				case '0':
		            SetColor(3);
	        		puts("Grazie per aver visitato il nostro negozio online!");
					SetColor(15);
					exit(1);
	        		break;
					
				case '1':
					userProfile();
					break;
					
		        case '2':
		            productSelection(showCatalogue, false);
		            break;
		            
		        case '3':
		            cartSelection(&cart_index, false);
		            break;
		            
		        case '4':
		        	showCart(&cart_index);
		        	system("pause");
					break;
				
				case '5':
					editCart(&cart_index);
					break;
				
				case '6':
					buyProduct(NULL);
					break;
				
				case '7':
					returnsAndRefunds();
					break;
					
		        default:
		        	errorChoice();
		    }
		}else
		{
			errorChoice();
		}
	}while(1);
}
